# WhatsApp Media System - Complete Archive

This archive contains all files related to WhatsApp media handling (both inbound and outbound), including all recent fixes and refactors.

## Source Code Files

### API Routes
- `src/app/api/media/messages/route.ts` - Media proxy route (handles media download with gate logic)
- `src/app/api/webhooks/whatsapp_route.ts` - Inbound WhatsApp webhook handler (processes incoming media with finalType)
- `src/app/api/inbox/conversations/conversation_route.ts` - Inbox conversation API (canonical isMedia detection)
- `src/app/api/inbox/conversations/messages_route.ts` - Outbound message sending (media upload)
- `src/app/api/admin/backfill-media-ids_route.ts` - Backfill script for historical messages
- `src/app/api/admin/whatsapp-media-health_route.ts` - Health check endpoint

### Library Functions
- `src/lib/media/whatsappMedia.ts` - WhatsApp media helper functions (fetching, streaming with redirect handling)
- `src/lib/media/extractMediaId.ts` - Media ID extraction logic (detectMediaType, extractMediaInfo)
- `src/lib/media/mediaTypeDetection.ts` - Media type detection utilities
- `src/lib/media/storage.ts` - Media storage utilities
- `src/lib/media/__tests__/extractMediaId.test.ts` - Unit tests for media extraction
- `src/lib/whatsapp-media-upload.ts` - Media upload to Meta Graph API
- `src/lib/whatsapp.ts` - Unified WhatsApp credentials helper (single source of truth)
- `src/lib/inbound/autoMatchPipeline.ts` - Inbound message processing pipeline (stores media metadata)

### UI Components
- `src/app/inbox/page.tsx` - Inbox UI (media rendering logic with canonical flags)
- `src/components/inbox/MediaMessage.tsx` - Media message component (renders images/videos/documents)
- `src/components/inbox/AudioMessagePlayer.tsx` - Audio player component

## Documentation Files

- `MEDIA_RENDERING_DIAGNOSIS.md` - Initial audit and diagnosis
- `WHATSAPP_CREDENTIALS_UNIFIED.md` - Unified credentials system documentation
- `MEDIA_RENDERING_RELIABILITY.md` - Media reliability improvements
- `MEDIA_RENDERING_RELIABILITY_IMPLEMENTATION.md` - Implementation details
- `MEDIA_PROXY_GATE_FIX.md` - Media proxy gate logic fix (hasMediaId)
- `MEDIA_PROXY_DEBUG_OUTPUT.md` - Debug output documentation
- `MEDIA_DOWNLOAD_REDIRECT_FIX.md` - Redirect handling fix
- `INBOX_MEDIA_CANONICAL_FIX.md` - Inbox media detection fix (canonical isMedia)
- `INBOUND_MEDIA_FINAL_FIX.md` - Inbound media classification fix (finalType)
- `MEDIA_BACKFILL_AND_TESTING.md` - Backfill and testing documentation
- `MEDIA_CLASSIFICATION_AND_BACKFILL.md` - Classification and backfill details

## Key Features Implemented

### Inbound Media Flow
1. Webhook receives message → `src/app/api/webhooks/whatsapp_route.ts`
2. Uses `finalType` for consistent classification
3. Extracts media info → `src/lib/media/extractMediaId.ts`
4. Stores in DB → `src/lib/inbound/autoMatchPipeline.ts`
5. Renders in inbox → `src/app/inbox/page.tsx` → `src/components/inbox/MediaMessage.tsx`
6. Fetches media → `src/app/api/media/messages/route.ts` → `src/lib/media/whatsappMedia.ts`

### Outbound Media Flow
1. User sends media → `src/app/api/inbox/conversations/messages_route.ts`
2. Uploads to Meta → `src/lib/whatsapp-media-upload.ts`
3. Stores message → Database with providerMediaId
4. Renders in inbox → Same as inbound

### Unified Credentials
- Single source of truth → `src/lib/whatsapp.ts` (getWhatsAppCredentials)
- Used by both upload and download paths
- Supports DB integration and env var fallback

### Media Detection
- Canonical `isMedia()` function checks: providerMediaId, numeric mediaUrl, MEDIA_TYPES, mediaMimeType
- Gate logic treats `hasMediaId` as definitive proof
- Supports all media types: image, document, audio, video, sticker

## Recent Fixes

1. **Unified Credentials** - Single source of truth for WhatsApp access tokens
2. **Inbound Media Classification** - Uses `finalType` consistently throughout
3. **Media Proxy Gate** - Treats `providerMediaId`/numeric `mediaUrl` as definitive proof
4. **Inbox Detection** - Canonical `isMedia()` function with `hasMedia` flag
5. **Redirect Handling** - Robust redirect handling for media downloads
6. **Sticker Support** - Full sticker support in all detection paths
7. **Backfill Script** - Historical message backfill with type correction

## Testing

- Unit tests: `src/lib/media/__tests__/extractMediaId.test.ts`
- Health check: `/api/admin/whatsapp-media-health`
- Backfill: `/api/admin/backfill-media-ids`

## Environment Variables

- `WHATSAPP_ACCESS_TOKEN` (preferred) or `META_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_VERIFY_TOKEN`

## Database Configuration

- Integration record: `name = 'whatsapp'`, `config.accessToken` (canonical)
- Fallback fields: `integration.accessToken`, `integration.apiKey`
