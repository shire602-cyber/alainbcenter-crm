import { NextRequest, NextResponse } from 'next/server'
import { requireAuthApi } from '@/lib/authApi'
import { prisma } from '@/lib/prisma'
import {
  getWhatsAppDownloadUrl,
  fetchWhatsAppMediaStream,
  getWhatsAppAccessToken,
} from '@/lib/media/whatsappMedia'

/**
 * GET /api/media/messages/[id]
 * 
 * Secure backend proxy for fetching media from provider (WhatsApp)
 * 
 * Flow:
 * 1. Fetch message by ID
 * 2. Check if message has providerMediaId (stored in mediaUrl for WhatsApp)
 * 3. Get download URL from Meta Graph API
 * 4. Stream media to client with proper headers
 * 
 * Supports:
 * - Range requests for audio/video streaming
 * - Proper Content-Type headers
 * - Secure token handling (server-side only)
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    await requireAuthApi()

    const resolvedParams = await params
    const messageId = parseInt(resolvedParams.id)

    if (isNaN(messageId)) {
      return NextResponse.json(
        { error: 'Invalid message ID' },
        { status: 400 }
      )
    }

    // Step 1: Fetch message with metadata/rawPayload for fallback media ID extraction
    const message = await prisma.message.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        type: true,
        mediaUrl: true, // This stores WhatsApp media ID (providerMediaId)
        mediaMimeType: true,
        channel: true,
        payload: true, // JSON metadata
        rawPayload: true, // Full webhook payload
        providerMessageId: true, // WhatsApp message ID for ExternalEventLog lookup
      },
    })

    if (!message) {
      return NextResponse.json(
        { error: 'Media not available', reason: 'Message not found' },
        { status: 404 }
      )
    }

    // Step 2: Normalize media source (priority: mediaUrl → metadata.mediaUrl → metadata.url → providerMediaId from rawPayload)
    // STEP 2: Normalize - treat "", " ", null, undefined as missing
    let providerMediaId: string | null = null
    
    // Priority 1: mediaUrl (trim and check)
    if (message.mediaUrl && typeof message.mediaUrl === 'string') {
      const trimmed = message.mediaUrl.trim()
      if (trimmed !== '') {
        providerMediaId = trimmed
      }
    }
    
    // Priority 2: Check metadata.payload for mediaUrl
    if (!providerMediaId && message.payload) {
      try {
        const metadata = typeof message.payload === 'string' ? JSON.parse(message.payload) : message.payload
        if (metadata?.mediaUrl && typeof metadata.mediaUrl === 'string') {
          const trimmed = metadata.mediaUrl.trim()
          if (trimmed !== '') {
            providerMediaId = trimmed
          }
        }
        // Priority 3: Check metadata.url
        if (!providerMediaId && metadata?.url && typeof metadata.url === 'string') {
          const trimmed = metadata.url.trim()
          if (trimmed !== '') {
            providerMediaId = trimmed
          }
        }
      } catch (e) {
        // Invalid JSON, skip
      }
    }
    
    // Priority 4: Extract from rawPayload (WhatsApp webhook structure)
    if (!providerMediaId && message.rawPayload) {
      try {
        console.log('[MEDIA-PROXY] Attempting rawPayload recovery', {
          messageId: message.id,
          rawPayloadLength: message.rawPayload.length,
        })
        
        const rawPayload = typeof message.rawPayload === 'string' ? JSON.parse(message.rawPayload) : message.rawPayload
        
        console.log('[MEDIA-PROXY] Parsed rawPayload', {
          messageId: message.id,
          hasAudio: !!rawPayload.audio,
          hasImage: !!rawPayload.image,
          hasDocument: !!rawPayload.document,
          hasVideo: !!rawPayload.video,
          rawPayloadKeys: Object.keys(rawPayload),
        })
        
        // Check WhatsApp audio/image/document structure
        if (rawPayload.audio?.id) {
          providerMediaId = String(rawPayload.audio.id).trim()
          console.log('[MEDIA-PROXY] ✅ Recovered audio media ID from rawPayload', {
            messageId: message.id,
            providerMediaId,
          })
        } else if (rawPayload.image?.id) {
          providerMediaId = String(rawPayload.image.id).trim()
          console.log('[MEDIA-PROXY] ✅ Recovered image media ID from rawPayload', {
            messageId: message.id,
            providerMediaId,
          })
        } else if (rawPayload.document?.id) {
          providerMediaId = String(rawPayload.document.id).trim()
          console.log('[MEDIA-PROXY] ✅ Recovered document media ID from rawPayload', {
            messageId: message.id,
            providerMediaId,
          })
        } else if (rawPayload.video?.id) {
          providerMediaId = String(rawPayload.video.id).trim()
          console.log('[MEDIA-PROXY] ✅ Recovered video media ID from rawPayload', {
            messageId: message.id,
            providerMediaId,
          })
        } else {
          console.log('[MEDIA-PROXY] rawPayload exists but no media ID found', {
            messageId: message.id,
            audioId: rawPayload.audio?.id,
            imageId: rawPayload.image?.id,
            documentId: rawPayload.document?.id,
            videoId: rawPayload.video?.id,
          })
        }
      } catch (e) {
        // Invalid JSON, skip
        console.warn('[MEDIA-PROXY] Failed to parse rawPayload:', e)
      }
    } else if (!providerMediaId) {
      console.log('[MEDIA-PROXY] No rawPayload available', {
        messageId: message.id,
      })
    }
    
    // Priority 5: Try to recover from ExternalEventLog (webhook payload storage)
    if (!providerMediaId && message.providerMessageId) {
      try {
        console.log('[MEDIA-PROXY] Attempting ExternalEventLog recovery', {
          messageId: message.id,
          providerMessageId: message.providerMessageId,
        })
        
        // Find ExternalEventLog entry with this providerMessageId
        const eventLog = await prisma.externalEventLog.findFirst({
          where: {
            provider: 'whatsapp',
            payload: {
              contains: message.providerMessageId,
            },
          },
          select: {
            id: true,
            payload: true,
            receivedAt: true,
          },
          orderBy: { receivedAt: 'desc' },
        })
        
        if (eventLog && eventLog.payload) {
          console.log('[MEDIA-PROXY] Found ExternalEventLog entry', {
            messageId: message.id,
            eventLogId: eventLog.id,
            payloadLength: eventLog.payload.length,
          })
          
          try {
            const webhookPayload = typeof eventLog.payload === 'string' ? JSON.parse(eventLog.payload) : eventLog.payload
            // Check if this webhook contains the message
            if (webhookPayload.entry?.[0]?.changes?.[0]?.value?.messages) {
              const messages = webhookPayload.entry[0].changes[0].value.messages
              const matchingMessage = messages.find((m: any) => m.id === message.providerMessageId)
              
              if (matchingMessage) {
                console.log('[MEDIA-PROXY] Found matching message in ExternalEventLog', {
                  messageId: message.id,
                  matchingMessageType: matchingMessage.type,
                  hasAudio: !!matchingMessage.audio,
                  hasImage: !!matchingMessage.image,
                  hasDocument: !!matchingMessage.document,
                })
                
                // Extract media ID from the webhook payload
                if (matchingMessage.audio?.id) {
                  providerMediaId = String(matchingMessage.audio.id).trim()
                  console.log('[MEDIA-PROXY] ✅ Recovered audio media ID from ExternalEventLog', {
                    messageId: message.id,
                    providerMediaId,
                    eventLogId: eventLog.id,
                  })
                } else if (matchingMessage.image?.id) {
                  providerMediaId = String(matchingMessage.image.id).trim()
                  console.log('[MEDIA-PROXY] ✅ Recovered image media ID from ExternalEventLog', {
                    messageId: message.id,
                    providerMediaId,
                    eventLogId: eventLog.id,
                  })
                } else if (matchingMessage.document?.id) {
                  providerMediaId = String(matchingMessage.document.id).trim()
                  console.log('[MEDIA-PROXY] ✅ Recovered document media ID from ExternalEventLog', {
                    messageId: message.id,
                    providerMediaId,
                    eventLogId: eventLog.id,
                  })
                } else if (matchingMessage.video?.id) {
                  providerMediaId = String(matchingMessage.video.id).trim()
                  console.log('[MEDIA-PROXY] ✅ Recovered video media ID from ExternalEventLog', {
                    messageId: message.id,
                    providerMediaId,
                    eventLogId: eventLog.id,
                  })
                } else {
                  console.log('[MEDIA-PROXY] Matching message found but no media ID', {
                    messageId: message.id,
                    matchingMessageKeys: Object.keys(matchingMessage),
                  })
                }
              } else {
                console.log('[MEDIA-PROXY] No matching message found in ExternalEventLog', {
                  messageId: message.id,
                  providerMessageId: message.providerMessageId,
                  messagesCount: messages.length,
                })
              }
            } else {
              console.log('[MEDIA-PROXY] ExternalEventLog payload structure unexpected', {
                messageId: message.id,
                hasEntry: !!webhookPayload.entry,
                hasChanges: !!webhookPayload.entry?.[0]?.changes,
                hasValue: !!webhookPayload.entry?.[0]?.changes?.[0]?.value,
                hasMessages: !!webhookPayload.entry?.[0]?.changes?.[0]?.value?.messages,
              })
            }
          } catch (e) {
            // Invalid JSON in payload, skip
            console.warn('[MEDIA-PROXY] Failed to parse ExternalEventLog payload:', e)
          }
        } else {
          console.log('[MEDIA-PROXY] No ExternalEventLog entry found', {
            messageId: message.id,
            providerMessageId: message.providerMessageId,
          })
        }
      } catch (e) {
        // ExternalEventLog query failed, skip
        console.warn('[MEDIA-PROXY] Failed to query ExternalEventLog:', e)
      }
    }
    
    // STEP 2: Debug logging (temporary)
    console.log('[MEDIA-PROXY] Normalized media source', {
      messageId: message.id,
      hasMediaUrl: !!message.mediaUrl,
      hasProviderMediaId: !!providerMediaId,
      source: providerMediaId ? 'found' : 'missing',
    })
    
    if (!providerMediaId || providerMediaId === '') {
      return NextResponse.json(
        { error: 'Media not available', reason: 'No media ID found in message (checked mediaUrl, metadata, rawPayload)' },
        { status: 404 }
      )
    }

    // Step 3: Determine provider and fetch media
    // Currently only WhatsApp is supported
    if (message.channel.toLowerCase() !== 'whatsapp') {
      return NextResponse.json(
        { error: 'Media not available', reason: `Channel ${message.channel} not supported` },
        { status: 404 }
      )
    }

    // Step 4: Get access token
    const accessToken = await getWhatsAppAccessToken()
    if (!accessToken) {
      return NextResponse.json(
        { error: 'Media not available', reason: 'WhatsApp access token not configured' },
        { status: 500 }
      )
    }

    // Step 5: Get download URL from Meta
    let mediaInfo
    try {
      mediaInfo = await getWhatsAppDownloadUrl(providerMediaId, accessToken)
    } catch (error: any) {
      console.error('[MEDIA-PROXY] Failed to get download URL:', error)
      return NextResponse.json(
        { error: 'Media not available', reason: error.message || 'Failed to fetch media URL from provider' },
        { status: 404 }
      )
    }

    // Step 6: Handle Range requests for audio/video streaming
    const rangeHeader = req.headers.get('range')

    // Step 7: Fetch media stream
    let mediaResponse
    try {
      mediaResponse = await fetchWhatsAppMediaStream(
        mediaInfo.url,
        accessToken,
        rangeHeader
      )
    } catch (error: any) {
      console.error('[MEDIA-PROXY] Failed to fetch media stream:', error)
      return NextResponse.json(
        { error: 'Media not available', reason: error.message || 'Failed to download media from provider' },
        { status: 500 }
      )
    }

    // Step 8: Prepare response headers
    const contentType = message.mediaMimeType || mediaInfo.mimeType || 'application/octet-stream'
    const contentLength = mediaResponse.headers.get('content-length')
    const contentRange = mediaResponse.headers.get('content-range')
    const upstreamStatus = mediaResponse.status

    const responseHeaders: HeadersInit = {
      'Content-Type': contentType,
      'Content-Disposition': `inline; filename="${mediaInfo.fileName || `media-${messageId}`}"`,
      'Accept-Ranges': 'bytes', // MANDATORY for audio/video streaming
      'Cache-Control': 'private, max-age=3600', // Cache for 1 hour (media URLs expire)
    }

    // Add Content-Length if available
    if (contentLength) {
      responseHeaders['Content-Length'] = contentLength
    }

    // Handle partial content (206) for Range requests
    if (rangeHeader && contentRange && upstreamStatus === 206) {
      responseHeaders['Content-Range'] = contentRange
      // Stream the response body directly (don't buffer)
      return new NextResponse(mediaResponse.body, {
        status: 206,
        headers: responseHeaders,
      })
    }

    // For non-Range requests, read the full buffer
    const arrayBuffer = await mediaResponse.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Log media response details
    console.log('[MEDIA-PROXY] Serving media', {
      messageId: message.id,
      providerMediaId,
      contentType,
      bufferSize: buffer.length,
      hasRange: !!rangeHeader,
      status: rangeHeader && contentRange ? 206 : 200,
    })

    // Return media file
    return new NextResponse(buffer, {
      status: upstreamStatus === 206 ? 206 : 200,
      headers: responseHeaders,
    })
  } catch (error: any) {
    console.error('[MEDIA-PROXY] Error:', error)
    return NextResponse.json(
      { error: 'Media not available', reason: error.message || 'Internal server error' },
      { status: 500 }
    )
  }
}

