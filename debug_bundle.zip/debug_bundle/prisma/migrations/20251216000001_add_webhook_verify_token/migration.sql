-- Add webhookVerifyToken field to Integration table for WhatsApp webhook verification
ALTER TABLE "Integration" ADD COLUMN "webhookVerifyToken" TEXT;























