'use client'

import { useState, useRef, useEffect } from 'react'
import { Play, Pause, Download, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface AudioMessagePlayerProps {
  mediaId: string
  mimeType?: string | null
  messageId: number
  className?: string
}

export function AudioMessagePlayer({ mediaId, mimeType, messageId, className }: AudioMessagePlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [duration, setDuration] = useState<number>(0)
  const [currentTime, setCurrentTime] = useState<number>(0)
  const [error, setError] = useState<string | null>(null)
  const audioRef = useRef<HTMLAudioElement>(null)

  // STEP 3: ALWAYS use proxy URL - mediaId should be /api/media/messages/:id
  useEffect(() => {
    if (!mediaId) return
    
    setIsLoading(true)
    setError(null)
    
    // STEP 3: mediaId should already be a proxy URL from the API
    // If it's not, construct it (backward compatibility)
    const proxyUrl = mediaId.startsWith('http') || mediaId.startsWith('/')
      ? mediaId
      : `/api/media/messages/${messageId}`
    
    // STEP 4: Debug logging (temporary)
    console.log('[AUDIO-DEBUG] Using proxy URL for audio', {
      mediaId,
      messageId,
      proxyUrl,
    })
    
    // STEP 3: Set proxy URL directly (browser will handle Range requests automatically)
    setAudioUrl(proxyUrl)
    setIsLoading(false)
  }, [mediaId, messageId])

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current
    if (!audio || !audioUrl) return

    const updateTime = () => setCurrentTime(audio.currentTime)
    const updateDuration = () => {
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration)
      }
    }
    const handlePlay = () => setIsPlaying(true)
    const handlePause = () => setIsPlaying(false)
    const handleEnded = () => setIsPlaying(false)
    const handleError = async (e: any) => {
      // STEP 3: Better error handling - check if it's a 404 (media not available)
      const audio = audioRef.current
      if (audio && audioUrl) {
        try {
          // Try to fetch the URL to see what error we get
          const response = await fetch(audioUrl, { method: 'HEAD' })
          if (response.status === 404) {
            setError('Audio unavailable - media not found in provider')
            console.log('[AUDIO-DEBUG] Proxy returned 404 for message', messageId)
          } else if (response.status >= 400) {
            setError(`Audio unavailable - server error (${response.status})`)
            console.error('[AUDIO-DEBUG] Proxy error', response.status, response.statusText)
          } else {
            setError('Failed to play audio. The file may be corrupted or in an unsupported format.')
            console.error('[AUDIO-DEBUG] Audio playback error:', e, 'Response status:', response.status)
          }
        } catch (fetchError: any) {
          // Network error or CORS issue
          setError('Audio unavailable - could not load media')
          console.error('[AUDIO-DEBUG] Fetch error:', fetchError.message)
        }
      } else {
        setError('Audio unavailable - no media URL')
        console.error('[AUDIO-DEBUG] No audio element or URL')
      }
      setIsPlaying(false)
      setIsLoading(false)
    }

    audio.addEventListener('timeupdate', updateTime)
    audio.addEventListener('loadedmetadata', updateDuration)
    audio.addEventListener('canplay', updateDuration)
    audio.addEventListener('play', handlePlay)
    audio.addEventListener('pause', handlePause)
    audio.addEventListener('ended', handleEnded)
    audio.addEventListener('error', handleError)

    // Try to load the audio
    if (audioUrl) {
      audio.load()
    }

    return () => {
      audio.removeEventListener('timeupdate', updateTime)
      audio.removeEventListener('loadedmetadata', updateDuration)
      audio.removeEventListener('canplay', updateDuration)
      audio.removeEventListener('play', handlePlay)
      audio.removeEventListener('pause', handlePause)
      audio.removeEventListener('ended', handleEnded)
      audio.removeEventListener('error', handleError)
    }
  }, [audioUrl])

  const togglePlay = async () => {
    const audio = audioRef.current
    if (!audio || !audioUrl) return

    try {
      if (isPlaying) {
        audio.pause()
        setIsPlaying(false)
      } else {
        await audio.play()
        setIsPlaying(true)
      }
    } catch (error: any) {
      console.error('Error toggling audio playback:', error)
      setError('Failed to play audio. Please try again.')
      setIsPlaying(false)
    }
  }

  const handleDownload = () => {
    if (!audioUrl) return
    const a = document.createElement('a')
    a.href = audioUrl
    a.download = `audio-message-${messageId}.${mimeType?.includes('ogg') ? 'ogg' : 'mp3'}`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
  }

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '0:00'
    const mins = Math.floor(seconds / 60)
    const secs = Math.floor(seconds % 60)
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0

  if (error) {
    return (
      <div className={cn('p-3 bg-red-50 dark:bg-red-900/20 rounded-lg border border-red-200 dark:border-red-800', className)}>
        <p className="text-sm text-red-700 dark:text-red-300">⚠️ {error}</p>
      </div>
    )
  }

  return (
    <div className={cn('flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-900 rounded-lg', className)}>
      {/* PART B FIX: Use proxy URL directly for Range support */}
      <audio ref={audioRef} src={audioUrl || undefined} preload="metadata" crossOrigin="anonymous" />
      
      <Button
        variant="ghost"
        size="sm"
        onClick={togglePlay}
        disabled={isLoading || !audioUrl}
        className="h-10 w-10 rounded-full p-0"
      >
        {isLoading ? (
          <Loader2 className="h-5 w-5 animate-spin" />
        ) : isPlaying ? (
          <Pause className="h-5 w-5" />
        ) : (
          <Play className="h-5 w-5" />
        )}
      </Button>

      <div className="flex-1 min-w-0">
        <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden mb-1">
          <div
            className="h-full bg-primary transition-all duration-100"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(duration)}</span>
        </div>
      </div>

      {audioUrl && (
        <Button
          variant="ghost"
          size="sm"
          onClick={handleDownload}
          className="h-8 w-8 p-0"
          title="Download audio"
        >
          <Download className="h-4 w-4" />
        </Button>
      )}
    </div>
  )
}

