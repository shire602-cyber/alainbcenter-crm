/**
 * WHATSAPP MEDIA HELPER
 * 
 * Helper functions for fetching WhatsApp media from Meta Graph API
 * Handles authentication, URL fetching, and streaming
 */

export interface WhatsAppMediaInfo {
  url: string
  mimeType: string
  fileSize?: number
  fileName?: string
}

/**
 * Get WhatsApp media download URL from Meta Graph API
 * @param mediaId - WhatsApp media ID (stored in Message.mediaUrl)
 * @param accessToken - WhatsApp access token
 * @returns Media download URL and metadata
 */
export async function getWhatsAppDownloadUrl(
  mediaId: string,
  accessToken: string
): Promise<WhatsAppMediaInfo> {
  // Step 1: Get media URL from Meta Graph API
  const response = await fetch(
    `https://graph.facebook.com/v21.0/${mediaId}`,
    {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    }
  )

  if (!response.ok) {
    const error = await response.json().catch(() => ({}))
    throw new Error(
      error.error?.message || `Failed to fetch media URL: ${response.statusText}`
    )
  }

  const data = await response.json()
  
  if (!data.url) {
    throw new Error('Media URL not found in Meta response')
  }

  return {
    url: data.url,
    mimeType: data.mime_type || 'application/octet-stream',
    fileSize: data.file_size ? parseInt(data.file_size) : undefined,
    fileName: data.filename || undefined,
  }
}

/**
 * Fetch WhatsApp media stream with Range support
 * @param mediaUrl - Download URL from getWhatsAppDownloadUrl
 * @param accessToken - WhatsApp access token
 * @param rangeHeader - Optional Range header for partial content requests
 * @returns Response with streamable body
 */
export async function fetchWhatsAppMediaStream(
  mediaUrl: string,
  accessToken: string,
  rangeHeader?: string | null
): Promise<Response> {
  const headers: HeadersInit = {
    Authorization: `Bearer ${accessToken}`,
  }

  // Forward Range header for audio/video streaming (seeking support)
  if (rangeHeader) {
    headers['Range'] = rangeHeader
  }

  const response = await fetch(mediaUrl, {
    headers,
  })

  if (!response.ok) {
    throw new Error(`Failed to download media: ${response.statusText}`)
  }

  return response
}

/**
 * Get WhatsApp access token from environment or database
 * @returns Access token or null
 */
export async function getWhatsAppAccessToken(): Promise<string | null> {
  // Try database first (Integration model)
  try {
    const { prisma } = await import('@/lib/prisma')
    const integration = await prisma.integration.findUnique({
      where: { name: 'whatsapp' },
    })

    if (integration?.config) {
      try {
        const config = typeof integration.config === 'string'
          ? JSON.parse(integration.config)
          : integration.config
        if (config.accessToken) {
          return config.accessToken
        }
      } catch {}
    }

    if (integration?.accessToken || integration?.apiKey) {
      return integration.accessToken || integration.apiKey
    }
  } catch (error) {
    // Fallback to env var
  }

  // Fallback to environment variable
  return process.env.WHATSAPP_ACCESS_TOKEN || 
         process.env.META_ACCESS_TOKEN || 
         null
}


