# Media Files Audit Package

This package contains all files related to media handling (images, PDFs, audio) in the CRM system.

## File Categories

### Core Media Proxy & API Routes
- `src/app/api/media/messages/[id]/route.ts` - Main media proxy endpoint that securely fetches media from WhatsApp
- `src/app/api/media/messages/[id]/route.test.ts` - Media proxy tests
- `src/app/api/media/route.ts` - Legacy media proxy for URL-based media
- `src/app/api/whatsapp/media/[mediaId]/route.ts` - Direct WhatsApp media access endpoint

### Media Library Functions
- `src/lib/media/whatsappMedia.ts` - WhatsApp Graph API helpers for fetching media
- `src/lib/whatsapp-media-upload.ts` - Media upload functions

### Webhook Handlers (Media Ingestion)
- `src/app/api/webhooks/whatsapp/route.ts` - WhatsApp webhook processing (extracts media IDs)
- `src/app/api/webhooks/whatsapp/diagnose/route.ts` - Webhook diagnostics
- `src/lib/inbound/autoMatchPipeline.ts` - Inbound message pipeline (stores media metadata)
- `src/lib/inbound.ts` - Inbound message handler

### API Routes (Message Formatting with Media)
- `src/app/api/inbox/conversations/[id]/route.ts` - Inbox conversation API (includes mediaProxyUrl)
- `src/app/api/inbox/conversations/[id]/messages/route.ts` - Inbox messages API
- `src/app/api/leads/[id]/messages/route.ts` - Lead messages API (includes mediaProxyUrl)

### UI Components (Media Rendering)
- `src/components/inbox/AudioMessagePlayer.tsx` - Audio player component
- `src/components/inbox/AudioRecorder.tsx` - Audio recorder component
- `src/components/leads/ConversationWorkspace.tsx` - Lead conversation view (renders media)
- `src/app/inbox/page.tsx` - Inbox page (renders media)

### Debug & Admin Tools
- `src/app/api/debug/media/probe/route.ts` - Media probe endpoint
- `src/app/api/debug/inbox/sample-media/route.ts` - Sample media endpoint
- `src/app/api/admin/backfill-media-ids/route.ts` - Backfill missing media IDs

### Test Files
- `scripts/test-media-api.ts` - Media API test script
- `scripts/check-media-messages.ts` - Media message checker
- `scripts/verify_prod_media.ts` - Production media verifier
- `e2e/test-c-audio-media.spec.ts` - Audio media E2E tests
- `e2e/test-d-image-media.spec.ts` - Image media E2E tests
- `e2e/test-e-pdf-media.spec.ts` - PDF media E2E tests
- `e2e/test-leads-media-comprehensive.spec.ts` - Comprehensive media tests

### Audio Transcription
- `src/lib/ai/transcribeAudio.ts` - Audio transcription function
- `src/lib/ai/__tests__/audioTranscription.test.ts` - Transcription tests

### WhatsApp Integration
- `src/lib/whatsapp.ts` - WhatsApp API functions

## Key Media Flow

1. **Webhook Ingestion**: WhatsApp webhook receives media message → extracts media ID → stores in `Message.mediaUrl`
2. **API Formatting**: API routes format messages with `mediaProxyUrl` pointing to `/api/media/messages/:id`
3. **Media Proxy**: Frontend requests `/api/media/messages/:id` → proxy fetches from WhatsApp Graph API → streams to client
4. **UI Rendering**: Components render media based on `mediaMimeType` (image, audio, document, video)

## Media Fields in Database

- `Message.mediaUrl` - Stores WhatsApp media ID (providerMediaId), not a URL
- `Message.mediaMimeType` - MIME type (e.g., "audio/ogg", "image/jpeg", "application/pdf")
- `Message.rawPayload` - Full webhook payload (used for recovery if mediaUrl is missing)
- `Message.payload` - Provider-specific metadata (JSON)

Generated: $(date)
