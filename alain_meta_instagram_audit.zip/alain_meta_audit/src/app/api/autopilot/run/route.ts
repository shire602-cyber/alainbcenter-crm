import { NextRequest, NextResponse } from 'next/server'
import { requireAdminApi } from '@/lib/authApi'
import { runAutopilot } from '@/lib/autopilot/runAutopilot'
import { prisma } from '@/lib/prisma'

// Configure for Vercel serverless
export const runtime = 'nodejs'
export const maxDuration = 300 // 5 minutes for automation runs

// POST /api/autopilot/run
// Manual trigger for autopilot (admin only)
export async function POST(req: NextRequest) {
  try {
    const user = await requireAdminApi()

    const body = await req.json().catch(() => ({}))
    // Default to false (actually send messages) unless explicitly set to dryRun
    const dryRun = body.dryRun === true
    console.log('🔧 Autopilot run mode:', dryRun ? 'DRY RUN (no messages sent)' : 'LIVE (messages will be sent)')

    // Update status to "Processing" in database
    try {
      await prisma.automationRunLog.create({
        data: {
          ruleKey: 'autopilot_manual_run',
          status: 'PROCESSING',
          message: 'Automation run queued',
          userId: user.id,
          ranAt: new Date(),
        },
      })
    } catch (logError) {
      console.warn('Failed to create processing log:', logError)
    }

    // Execute autopilot directly - don't use queue for manual runs
    // This ensures we get immediate results and proper error handling
    console.log('🚀 Running autopilot directly (manual trigger)', { dryRun, userId: user.id })
    
    let result
    try {
      result = await runAutopilot({ dryRun })
      console.log('✅ Autopilot run completed:', {
        rules: result.totals.rules,
        sent: result.totals.sent,
        skipped: result.totals.skipped,
        failed: result.totals.failed,
      })
    } catch (autopilotError: any) {
      console.error('❌ Autopilot execution failed:', autopilotError)
      // Update log status to failed
      try {
        await prisma.automationRunLog.updateMany({
          where: {
            ruleKey: 'autopilot_manual_run',
            status: 'PROCESSING',
            userId: user.id,
          },
          data: {
            status: 'FAILED',
            message: `Failed: ${autopilotError.message || 'Unknown error'}`,
          },
        })
      } catch (logError) {
        console.warn('Failed to update log status:', logError)
      }
      throw autopilotError // Re-throw to be caught by outer catch
    }

    // Update log status to completed
    try {
      await prisma.automationRunLog.updateMany({
        where: {
          ruleKey: 'autopilot_manual_run',
          status: 'PROCESSING',
          userId: user.id,
        },
        data: {
          status: 'COMPLETED',
          message: `Completed: ${result.totals.rules} rules, ${result.totals.sent} sent, ${result.totals.skipped} skipped, ${result.totals.failed} failed`,
        },
      })
    } catch (logError) {
      console.warn('Failed to update log status:', logError)
    }

    // Return results immediately
    return NextResponse.json({
      ok: true,
      message: 'Automation run completed successfully',
      status: 'completed',
      processing: false,
      timestamp: new Date().toISOString(),
      totals: {
        rules: result.totals.rules || 0,
        sent: result.totals.sent || 0,
        skipped: result.totals.skipped || 0,
        failed: result.totals.failed || 0,
      },
    })
  } catch (error: any) {
    console.error('Autopilot run error:', error)
    return NextResponse.json(
      {
        ok: false,
        error: error.message || 'Failed to run autopilot',
      },
      { status: error.statusCode || 500 }
    )
  }
}























