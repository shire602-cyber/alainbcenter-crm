import { NextRequest, NextResponse } from 'next/server'
import { requireAdminApi } from '@/lib/authApi'
import { checkWhatsAppConfiguration, getWhatsAppAccessTokenInternal } from '@/lib/whatsapp'
import { prisma } from '@/lib/prisma'
import { MEDIA_TYPES } from '@/lib/media/extractMediaId'

/**
 * GET /api/admin/whatsapp-media-health
 * Health check endpoint for WhatsApp media configuration and proxy
 * Reports token source, token presence, and optionally tests media fetch
 * ADMIN ONLY
 * 
 * Query params:
 * - testMediaId: optional media ID to test fetch (will attempt to fetch metadata)
 */
export async function GET(req: NextRequest) {
  try {
    await requireAdminApi()

    const url = new URL(req.url)
    const testMediaId = url.searchParams.get('testMediaId')

    // Check configuration
    const configCheck = await checkWhatsAppConfiguration()

    // Get token (for testing if needed)
    const token = await getWhatsAppAccessTokenInternal()

    // Test media fetch if mediaId provided
    let mediaTest: any = null
    if (testMediaId && token) {
      try {
        const response = await fetch(`https://graph.facebook.com/v18.0/${testMediaId}`, {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        })

        if (response.ok) {
          const mediaData = await response.json()
          mediaTest = {
            success: true,
            hasUrl: !!mediaData.url,
            mimeType: mediaData.mime_type || null,
            fileSize: mediaData.file_size || null,
            sha256: mediaData.sha256 || null,
          }
        } else {
          mediaTest = {
            success: false,
            status: response.status,
            statusText: response.statusText,
            error: await response.text().catch(() => 'Unknown error'),
          }
        }
      } catch (e: any) {
        mediaTest = {
          success: false,
          error: e.message,
        }
      }
    }

    // Get stats on messages with missing providerMediaId
    const missingMediaIdStats = await prisma.message.groupBy({
      by: ['type'],
      where: {
        AND: [
          {
            OR: [
              { type: { in: Array.from(MEDIA_TYPES) } },
              { mediaMimeType: { not: null } },
            ],
          },
          { providerMediaId: null },
        ],
      },
      _count: {
        id: true,
      },
    })

    const totalMissing = missingMediaIdStats.reduce((sum, stat) => sum + stat._count.id, 0)

    return NextResponse.json({
      ok: true,
      configuration: {
        tokenPresent: configCheck.tokenPresent,
        tokenSource: configCheck.tokenSource,
        phoneNumberIdPresent: configCheck.phoneNumberIdPresent,
      },
      mediaTest: testMediaId ? mediaTest : { message: 'No testMediaId provided' },
      stats: {
        messagesWithMissingProviderMediaId: totalMissing,
        byType: missingMediaIdStats.map(stat => ({
          type: stat.type,
          count: stat._count.id,
        })),
      },
      recommendations: [
        !configCheck.tokenPresent && 'Configure WhatsApp access token (DB Integration config.accessToken or WHATSAPP_ACCESS_TOKEN env var)',
        !configCheck.phoneNumberIdPresent && 'Configure WhatsApp phone number ID',
        totalMissing > 0 && `Run backfill to fix ${totalMissing} messages with missing providerMediaId: POST /api/admin/backfill-media-ids`,
      ].filter(Boolean),
    })
  } catch (error: any) {
    console.error('WhatsApp media health check error:', error)
    return NextResponse.json(
      { 
        ok: false, 
        error: error.message,
      },
      { status: 500 }
    )
  }
}
