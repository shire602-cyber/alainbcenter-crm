'use client'

import { useEffect, useState, useRef, FormEvent, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { MainLayout } from '@/components/layout/MainLayout'
import { BentoCard } from '@/components/dashboard/BentoCard'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import { Skeleton } from '@/components/ui/skeleton'
import { EmptyState } from '@/components/ui/empty-state'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Inbox as InboxIcon,
  Search,
  Send,
  MessageSquare,
  CheckCircle2,
  CheckCheck,
  Clock,
  Loader2,
  XCircle,
  Sparkles,
  Phone,
  Mail,
  MessageCircle,
  Instagram,
  Facebook,
  Globe,
  Eye,
  Users,
  Image as ImageIcon,
  FileText,
  Video,
  MapPin,
  Paperclip,
  X,
  Sparkles as SparklesIcon,
  UserPlus,
  Trash2,
  AlertTriangle,
  Music,
} from 'lucide-react'
import { format, isToday, isYesterday, differenceInDays, parseISO } from 'date-fns'
import { cn } from '@/lib/utils'
import Link from 'next/link'
import { AudioMessagePlayer } from '@/components/inbox/AudioMessagePlayer'
import { MediaMessage } from '@/components/inbox/MediaMessage'
import { hasMedia, detectMediaType } from '@/lib/media/mediaTypeDetection'
import { MEDIA_TYPES } from '@/lib/media/extractMediaId'
import { Select } from '@/components/ui/select'

type Contact = {
  id: number
  fullName: string
  phone: string
  email?: string | null
}

type Conversation = {
  id: number
  contact: Contact
  channel: string
  status: string
  lastMessageAt: string
  unreadCount: number
  lastMessage: {
    id: number
    direction: string
    body: string
    createdAt: string
  } | null
  createdAt: string
  assignedUser: {
    id: number
    name: string
    email: string
  } | null
}

type Message = {
  id: number
  direction: string
  channel: string
  type: string
  body: string | null
  mediaUrl: string | null // Stores providerMediaId for WhatsApp
  mediaMimeType: string | null
  mediaProxyUrl?: string | null // PHASE 3: Proxy URL for secure media access
  mediaRenderable?: boolean // PHASE 3: Whether media can be rendered via proxy
  mediaFilename?: string | null // Media filename
  status: string
  providerMessageId: string | null
  sentAt: string | null
  createdBy: {
    id: number
    name: string
    email: string
  } | null
  createdAt: string
  // PHASE 5A: Include attachments
  attachments?: Array<{
    id: number
    type: string
    url: string
    mimeType: string | null
    filename: string | null
    sizeBytes: number | null
    durationSec: number | null
    thumbnailUrl: string | null
  }>
}

type Lead = {
  id: number
  contact: {
    id: number
    fullName: string
    phone: string
    email?: string | null
  }
  stage: string
  pipelineStage?: string
  leadType?: string | null
  serviceType: {
    id: number
    name: string
  } | null
  priority: string | null
  aiScore: number | null
  notes: string | null
  nextFollowUpAt: string | null
  expiryDate: string | null
  assignedUser: {
    id: number
    name: string
    email: string
  } | null
  expiryItems?: Array<{
    id: number
    type: string
    expiryDate: string
  }>
}

const CHANNELS = [
  { value: 'all', label: 'All Channels', icon: InboxIcon },
  { value: 'whatsapp', label: 'WhatsApp', icon: MessageSquare },
  { value: 'instagram', label: 'Instagram', icon: Instagram },
  { value: 'facebook', label: 'Facebook', icon: Facebook },
  { value: 'email', label: 'Email', icon: Mail },
  { value: 'webchat', label: 'Web Chat', icon: Globe },
] as const

// PART 2: Helper to extract message text from various fields
function getMessageDisplayText(msg: any): string | null {
  // Check all possible text fields
  if (msg.text) return msg.text
  if (msg.body) return msg.body
  if (msg.content) return msg.content
  if (msg.caption) return msg.caption
  if (msg.payload?.text?.body) return msg.payload.text.body
  if (msg.payload?.button?.text) return msg.payload.button.text
  if (msg.payload?.interactive?.body?.text) return msg.payload.interactive.body.text
  return null
}

// STEP 3: Removed renderPlaceholderMedia - always try proxy first
// The proxy will return 404 if media is truly unavailable
// This ensures we don't show "unavailable" for messages that might have media in metadata/rawPayload

function InboxPageContent() {
  // STEP 0: Build stamp for deployment verification
  const [buildInfo, setBuildInfo] = useState<{ buildId?: string; buildTime?: string } | null>(null)
  
  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => setBuildInfo({ buildId: data.buildId, buildTime: data.buildTime }))
      .catch(() => {})
  }, [])
  
  // Helper to get media URL - PRIORITY: Use mediaProxyUrl if available, otherwise construct from mediaUrl
  // CRITICAL: Defined outside map to prevent Webpack bundling issues
  const getMediaUrl = (msg: Message): string => {
    // #region agent log
    try {
      fetch('http://127.0.0.1:7242/ingest/a9581599-2981-434f-a784-3293e02077df',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'inbox/page.tsx:getMediaUrl',message:'getMediaUrl called',data:{messageId:msg.id,hasMediaProxyUrl:!!msg.mediaProxyUrl,mediaRenderable:msg.mediaRenderable,mediaUrl:msg.mediaUrl,mediaUrlType:typeof msg.mediaUrl},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'M1'})}).catch(()=>{});
    } catch (e) {}
    // #endregion
    
    // CRITICAL FIX: ALWAYS use proxy URL for media messages, even if mediaUrl is null
    // The proxy will try to recover from payload/rawPayload/ExternalEventLog
    // FIX: Use centralized media detection logic
    const hasMediaResult = hasMedia(msg.type, msg.mediaMimeType)
    
    if (hasMediaResult) {
      // ALWAYS use proxy - it will try recovery
      const proxyUrl = msg.mediaProxyUrl || `/api/media/messages/${msg.id}`
      return proxyUrl
    }
    
    // PRIORITY 1: Use mediaProxyUrl if available
    if (msg.mediaProxyUrl) {
      return msg.mediaProxyUrl
    }
    
    // PRIORITY 2: Fallback to constructing URL from mediaUrl (WhatsApp media ID)
    const mediaUrl = typeof msg.mediaUrl === 'string' ? msg.mediaUrl : null
    if (!mediaUrl || mediaUrl.trim() === '') {
      return ''
    }
    const result = mediaUrl.startsWith('http') || mediaUrl.startsWith('/')
      ? mediaUrl
      : `/api/media/messages/${msg.id}` // Use main media proxy endpoint
    // #region agent log
    try {
      fetch('http://127.0.0.1:7242/ingest/a9581599-2981-434f-a784-3293e02077df',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'inbox/page.tsx:getMediaUrl',message:'getMediaUrl returning constructed URL',data:{messageId:msg.id,result,isProxy:!mediaUrl.startsWith('http')&&!mediaUrl.startsWith('/')},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'M1'})}).catch(()=>{});
    } catch (e) {}
    // #endregion
    return result
  }
  
  const searchParams = useSearchParams()
  const phoneParam = searchParams?.get('phone')
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedConversation, setSelectedConversation] = useState<Conversation | null>(null)
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMessages, setLoadingMessages] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [newMessage, setNewMessage] = useState('')
  const [sending, setSending] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [generatingDraft, setGeneratingDraft] = useState(false)
  const [activeChannel, setActiveChannel] = useState<string>('all')
  const [uploading, setUploading] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [showAudioRecorder, setShowAudioRecorder] = useState(false)
  const [users, setUsers] = useState<Array<{ id: number; name: string; email: string; role: string }>>([])
  const [user, setUser] = useState<{ id: number; name: string; email: string; role: string } | null>(null)
  const [assigning, setAssigning] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' })
    }
  }, [messages])

  async function loadConversations() {
    try {
      setLoading(true)
      const channelParam = activeChannel === 'all' ? 'channel=all' : `channel=${activeChannel}`
      const res = await fetch(`/api/inbox/conversations?${channelParam}`)
      const data = await res.json()

      if (data.ok) {
        setConversations(data.conversations || [])
      } else {
        setError(data.error || 'Failed to load conversations')
      }
    } catch (err: any) {
      setError('Failed to load conversations')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadConversations()
    // Load current user
    fetch('/api/auth/me')
      .then(res => res.json())
      .then(data => setUser(data.user))
      .catch(() => {})
    // Load users for assignment (if admin)
    fetch('/api/admin/users')
      .then(res => res.json())
      .then(data => {
        if (data.ok && data.users) {
          setUsers(data.users)
        }
      })
      .catch(() => {})
  }, [activeChannel])

  // Auto-refresh: Poll for new messages every 3 seconds (silent background refresh)
  useEffect(() => {
    const interval = setInterval(() => {
      // Silent background refresh - don't show loading states
      const channelParam = activeChannel === 'all' ? 'channel=all' : `channel=${activeChannel}`
      fetch(`/api/inbox/conversations?${channelParam}`)
        .then(res => res.json())
        .then(data => {
          if (data.ok) {
            // Smoothly update conversations without jarring transitions
            setConversations(prev => {
              // Merge new conversations with existing ones to maintain scroll position
              const existingMap = new Map(prev.map(c => [c.id, c]))
              const newConversations = (data.conversations || []).map((newConv: Conversation) => {
                const existing = existingMap.get(newConv.id)
                // Preserve selection state
                return existing && existing.id === selectedConversation?.id 
                  ? { ...newConv, ...existing }
                  : newConv
              })
              return newConversations
            })
          }
        })
        .catch(() => {}) // Silent fail for background refresh
      
      // Refresh messages if a conversation is selected (silent)
      if (selectedConversation) {
        fetch(`/api/inbox/conversations/${selectedConversation.id}`)
          .then(res => res.json())
          .then(data => {
            if (data.ok && data.conversation) {
              // Smoothly update messages without clearing the list
              setMessages(prev => {
                const existingMap = new Map(prev.map(m => [m.id, m]))
                const newMessages = (data.conversation.messages || []).map((newMsg: Message) => {
                  const existing = existingMap.get(newMsg.id)
                  return existing || newMsg
                })
                // Only update if there are actually new messages
                if (newMessages.length !== prev.length || 
                    newMessages.some((m: Message, i: number) => m.id !== prev[i]?.id)) {
                  return newMessages
                }
                return prev
              })
              setSelectedLead(data.conversation.lead)
            }
          })
          .catch(() => {}) // Silent fail
      }
    }, 3000) // Poll every 3 seconds

    return () => clearInterval(interval)
  }, [selectedConversation, activeChannel])

  async function loadMessages(conversationId: number, silent: boolean = false) {
    try {
      if (!silent) setLoadingMessages(true)
      setError(null)

      await fetch(`/api/inbox/conversations/${conversationId}/read`, {
        method: 'POST',
      })

      const res = await fetch(`/api/inbox/conversations/${conversationId}`)
      const data = await res.json()
      
      // #region agent log
      try {
        const messagesWithMedia = (data.conversation?.messages || []).filter((m: any) => m.mediaUrl || (m.attachments && m.attachments.length > 0))
        fetch('http://127.0.0.1:7242/ingest/a9581599-2981-434f-a784-3293e02077df',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'inbox/page.tsx:loadMessages',message:'API response received',data:{conversationId,ok:data.ok,hasConversation:!!data.conversation,messagesCount:data.conversation?.messages?.length||0,messagesWithMediaCount:messagesWithMedia.length,messagesWithMedia:messagesWithMedia.map((m:any)=>({id:m.id,type:m.type,mediaUrl:m.mediaUrl,attachmentsCount:m.attachments?.length||0}))},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'M4'})}).catch(()=>{});
      } catch (e) {}
      // #endregion

      if (data.ok && data.conversation) {
        // Smooth transition - preserve existing messages and fade in new ones
        setMessages(prev => {
          const newMessages = data.conversation.messages || []
          // If messages are the same, don't update to prevent flicker
          if (prev.length === newMessages.length && 
              prev.every((m, i) => m.id === newMessages[i]?.id)) {
            return prev
          }
          return newMessages
        })
        setSelectedLead(data.conversation.lead)
        setConversations((prev) =>
          prev.map((c) =>
            c.id === conversationId
              ? { ...c, unreadCount: 0, lastMessage: data.conversation.lastMessage }
              : c
          )
        )
      } else {
        if (!silent) setError(data.error || 'Failed to load messages')
      }
    } catch (err: any) {
      if (!silent) setError('Failed to load messages')
      console.error(err)
    } finally {
      if (!silent) setLoadingMessages(false)
    }
  }

  async function handleSelectConversation(conversation: Conversation) {
    setSelectedConversation(conversation)
    await loadMessages(conversation.id)
    // Clear phone param from URL after selecting
    if (phoneParam) {
      const url = new URL(window.location.href)
      url.searchParams.delete('phone')
      window.history.replaceState({}, '', url.toString())
    }
  }

  // Handle phone number query parameter to auto-select conversation
  useEffect(() => {
    if (phoneParam && conversations.length > 0) {
      const matchingConv = conversations.find(c => 
        c.contact.phone?.replace(/[^0-9]/g, '') === phoneParam.replace(/[^0-9]/g, '')
      )
      if (matchingConv && matchingConv.id !== selectedConversation?.id) {
        handleSelectConversation(matchingConv)
      }
    }
  }, [conversations, phoneParam])

  async function handleFileSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file size (16MB max for WhatsApp)
    const maxSize = 16 * 1024 * 1024
    if (file.size > maxSize) {
      setError(`File size exceeds 16MB limit. Selected file: ${(file.size / 1024 / 1024).toFixed(2)}MB`)
      return
    }

    setSelectedFile(file)
    setError(null)
    setShowAudioRecorder(false) // Hide recorder if file selected
  }

  async function handleAudioRecordingComplete(audioBlob: Blob) {
    // Create a File object from the blob
    const audioFile = new File([audioBlob], `recording-${Date.now()}.webm`, {
      type: 'audio/webm',
    })
    
    setSelectedFile(audioFile)
    setShowAudioRecorder(false)
    setError(null)
    
    // Auto-upload and send the recording
    setTimeout(() => {
      handleUploadFile()
    }, 100)
  }

  async function handleUploadFile() {
    if (!selectedFile || !selectedConversation) return

    setUploading(true)
    setError(null)
    setSuccess(null)
    setUploadProgress(0)

    try {
      // Step 1: Upload file to get public URL
      const formData = new FormData()
      formData.append('file', selectedFile)

      const uploadRes = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      if (!uploadRes.ok) {
        const error = await uploadRes.json()
        throw new Error(error.error || 'Failed to upload file')
      }

      setUploadProgress(50)

      const uploadData = await uploadRes.json()
      const mediaId = uploadData.mediaId // Meta media ID (not URL)

      if (!mediaId) {
        throw new Error('Upload succeeded but no media ID returned')
      }

      // Step 2: Determine media type
      let mediaType: 'image' | 'document' | 'video' | 'audio' = 'document'
      if (selectedFile.type.startsWith('image/')) {
        mediaType = 'image'
      } else if (selectedFile.type.startsWith('video/')) {
        mediaType = 'video'
      } else if (selectedFile.type.startsWith('audio/')) {
        mediaType = 'audio'
      }

      setUploadProgress(75)

      // Step 3: Send media message using media ID
      const res = await fetch(`/api/inbox/conversations/${selectedConversation.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mediaId, // Use media ID instead of URL
          mediaType,
          mediaCaption: newMessage.trim() || undefined,
          mediaFilename: selectedFile.name,
        }),
      })

      const data = await res.json()

      if (data.ok) {
        setSuccess('Media sent successfully!')
        setNewMessage('')
        setSelectedFile(null)
        if (fileInputRef.current) {
          fileInputRef.current.value = ''
        }
        await loadMessages(selectedConversation.id)
        await loadConversations()
      } else {
        setError(data.error || 'Failed to send media')
        if (data.hint) {
          setError(`${data.error}\n💡 ${data.hint}`)
        }
      }
    } catch (err: any) {
      setError(err.message || 'Failed to upload and send file')
      console.error(err)
    } finally {
      setUploading(false)
      setUploadProgress(0)
    }
  }

  async function handleSendMessage(e: FormEvent) {
    e.preventDefault()
    if (!selectedConversation) return

    // If file is selected, upload it instead
    if (selectedFile) {
      await handleUploadFile()
      return
    }

    if (!newMessage.trim()) return

    setSending(true)
    setError(null)
    setSuccess(null)

    try {
      const res = await fetch(`/api/inbox/conversations/${selectedConversation.id}/messages`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: newMessage.trim() }),
      })

      const data = await res.json()

      if (data.ok) {
        setSuccess('Message sent successfully!')
        setNewMessage('')
        await loadMessages(selectedConversation.id)
        await loadConversations()
      } else {
        setError(data.error || 'Failed to send message')
        if (data.hint) {
          setError(`${data.error}\n💡 ${data.hint}`)
        }
      }
    } catch (err: any) {
      setError('Failed to send message')
      console.error(err)
    } finally {
      setSending(false)
    }
  }

  function formatMessageTime(dateString: string) {
    const date = new Date(dateString)
    if (isToday(date)) {
      return format(date, 'HH:mm')
    } else if (isYesterday(date)) {
      return `Yesterday ${format(date, 'HH:mm')}`
    } else {
      return format(date, 'MMM dd, HH:mm')
    }
  }

  function getInitials(name: string) {
    return name
      .split(' ')
      .map((n) => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2)
  }

  function needsReply(conv: Conversation): boolean {
    if (!conv.lastMessage || conv.lastMessage.direction !== 'inbound') return false
    const lastMessageTime = new Date(conv.lastMessageAt)
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000)
    return lastMessageTime < oneHourAgo
  }

  function getChannelIcon(channel: string) {
    switch (channel.toLowerCase()) {
      case 'whatsapp':
        return MessageSquare
      case 'instagram':
        return Instagram
      case 'facebook':
        return Facebook
      case 'email':
        return Mail
      case 'webchat':
        return Globe
      default:
        return MessageCircle
    }
  }

  const filteredConversations = conversations.filter((conv) => {
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return (
      conv.contact.fullName.toLowerCase().includes(query) ||
      conv.contact.phone.includes(query) ||
      conv.lastMessage?.body.toLowerCase().includes(query)
    )
  })

  return (
    <MainLayout>
      <div className="flex h-[calc(100vh-4rem)] gap-2">
        {/* Left Panel: Conversation List - Compact */}
        <BentoCard className="w-80 flex-shrink-0 rounded-none border-r flex flex-col p-0 overflow-hidden">
          {/* Header */}
          <div className="p-3 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-3">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                <InboxIcon className="h-4 w-4 text-primary" />
              </div>
              <h1 className="text-lg font-semibold tracking-tight">Inbox</h1>
            </div>

            {/* Channel Tabs */}
            <Tabs value={activeChannel} onValueChange={setActiveChannel}>
              <TabsList className="grid w-full grid-cols-3 h-auto gap-1">
                {CHANNELS.map((channel) => {
                  const Icon = channel.icon
                  return (
                    <TabsTrigger
                      key={channel.value}
                      value={channel.value}
                      className="flex flex-col h-auto py-1.5 text-xs"
                    >
                      <Icon className="h-3.5 w-3.5 mb-0.5" />
                      <span>{channel.label}</span>
                    </TabsTrigger>
                  )
                })}
              </TabsList>
            </Tabs>
            </div>

          {/* Search */}
          <div className="p-3 border-b border-slate-200 dark:border-slate-800">
            <div className="relative">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-slate-400" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 h-8 text-xs"
              />
            </div>
          </div>

          {/* Conversation List */}
          <div className="flex-1 overflow-y-auto p-2">
            {loading ? (
              <div className="space-y-2">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-16 w-full rounded-lg" />
                ))}
              </div>
            ) : filteredConversations.length === 0 ? (
              <EmptyState
                icon={MessageSquare}
                title="No conversations"
                description="Start a conversation to see it here."
              />
            ) : (
              <div className="space-y-1">
                {filteredConversations.map((conv) => {
                  const ChannelIcon = getChannelIcon(conv.channel)
                  return (
                    <div
                      key={conv.id}
                      className={cn(
                        'flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all hover:bg-slate-100 dark:hover:bg-slate-800/50',
                        selectedConversation?.id === conv.id && 'bg-primary/5 border border-primary/20'
                      )}
                      onClick={() => handleSelectConversation(conv)}
                    >
                      <Avatar fallback={conv.contact.fullName && !conv.contact.fullName.includes('Unknown') ? conv.contact.fullName : conv.contact.phone} size="sm" />
                        <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <p className="font-medium text-xs truncate text-slate-900 dark:text-slate-100">
                              {conv.contact.fullName && !conv.contact.fullName.includes('Unknown') 
                                ? conv.contact.fullName 
                                : conv.contact.phone}
                            </p>
                          <div className="flex items-center gap-1 shrink-0">
                            <ChannelIcon className="h-3 w-3 text-slate-400" />
                              {conv.unreadCount > 0 && (
                              <Badge className="text-xs h-4 px-1.5">
                                  {conv.unreadCount}
                                </Badge>
                              )}
                            </div>
                          </div>
                        <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                          <p className="truncate flex-1">
                            {conv.lastMessage?.direction === 'outbound' ? 'You: ' : ''}
                            {conv.lastMessage?.body || 'No messages'}
                            </p>
                          <span className="ml-1 shrink-0">{formatMessageTime(conv.lastMessageAt)}</span>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </BentoCard>

        {/* Right Panel: Messages - Compact */}
        <BentoCard className="flex-1 flex flex-col rounded-none p-0 overflow-hidden">
          {selectedConversation ? (
            <>
              <div className="p-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <Avatar fallback={selectedConversation.contact.fullName || selectedConversation.contact.phone} size="md" />
                    <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-semibold tracking-tight truncate">
                      {selectedConversation.contact.fullName && 
                       !selectedConversation.contact.fullName.includes('Unknown') 
                        ? selectedConversation.contact.fullName 
                        : selectedConversation.contact.phone}
                    </h3>
                    {selectedConversation.contact.fullName && 
                     !selectedConversation.contact.fullName.includes('Unknown') && (
                      <p className="text-xs text-slate-500 dark:text-400 truncate">
                        {selectedConversation.contact.phone}
                      </p>
                    )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {/* AI/User Toggle - Always visible for all users */}
                    <Select
                      value={selectedConversation.assignedUser?.id?.toString() || 'ai'}
                      onChange={async (e) => {
                        const value = e.target.value
                        if (!selectedConversation) return
                        
                        setAssigning(true)
                        try {
                          const res = await fetch(`/api/inbox/conversations/${selectedConversation.id}/assign`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({
                              assignedToAI: value === 'ai',
                              assignedUserId: value === 'ai' ? null : parseInt(value),
                            }),
                          })
                          
                          const data = await res.json()
                          if (res.ok) {
                            setSuccess(data.message || value === 'ai' ? 'Switched to AI mode' : 'Switched to User mode')
                            setError(null)
                            // Reload conversations to get updated assignment
                            await loadConversations()
                            // Reload selected conversation to get updated assignment
                            const convRes = await fetch(`/api/inbox/conversations/${selectedConversation.id}`)
                            if (convRes.ok) {
                              const convData = await convRes.json()
                              if (convData.ok && convData.conversation) {
                                // Map the conversation response to match the Conversation type
                                const updatedConv: Conversation = {
                                  id: convData.conversation.id,
                                  contact: convData.conversation.contact,
                                  channel: convData.conversation.channel,
                                  status: convData.conversation.status,
                                  lastMessageAt: convData.conversation.lastMessageAt,
                                  unreadCount: convData.conversation.unreadCount || 0,
                                  lastMessage: convData.conversation.lastMessage,
                                  createdAt: convData.conversation.createdAt,
                                  assignedUser: convData.conversation.assignedUser || null,
                                }
                                setSelectedConversation(updatedConv)
                                // Also update in conversations list
                                setConversations(prev => prev.map(c => 
                                  c.id === selectedConversation.id ? updatedConv : c
                                ))
                              }
                            }
                          } else {
                            setError(data.error || 'Failed to switch mode')
                            setSuccess(null)
                          }
                        } catch (err: any) {
                          setError('Failed to switch mode')
                        } finally {
                          setAssigning(false)
                        }
                      }}
                      disabled={assigning}
                      className="h-8 text-xs min-w-[120px]"
                    >
                      <option value="ai">🤖 AI</option>
                      {user && (
                        <option value={user.id.toString()}>
                          👤 {user.name} (Me)
                        </option>
                      )}
                      {user?.role === 'ADMIN' && users.filter(u => u.id !== user?.id).map((u) => (
                        <option key={u.id} value={u.id.toString()}>
                          👤 {u.name}
                        </option>
                      ))}
                    </Select>
                    {selectedLead && (
                    <Link href={`/leads/${selectedLead.id}`} target="_blank">
                      <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                        <Eye className="h-3.5 w-3.5" />
                        View Lead
                      </Button>
                    </Link>
                    )}
                    {user?.role === 'ADMIN' && selectedConversation && (
                      <Button
                        variant="outline"
                        size="sm"
                        className="gap-1.5 text-xs text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                        onClick={async () => {
                          if (!confirm('⚠️ Delete this conversation and all messages? This action cannot be undone. This is for testing purposes only.')) {
                            return
                          }
                          try {
                            setDeleting(true)
                            setError(null)
                            const res = await fetch(`/api/admin/conversations/${selectedConversation.id}/delete`, {
                              method: 'DELETE',
                              credentials: 'include',
                            })
                            const data = await res.json()
                            if (data.ok) {
                              setSuccess(`Deleted conversation and ${data.deletedMessages} messages`)
                              setSelectedConversation(null)
                              setMessages([])
                              await loadConversations()
                            } else {
                              setError(data.error || 'Failed to delete conversation')
                            }
                          } catch (err: any) {
                            setError('Failed to delete conversation')
                          } finally {
                            setDeleting(false)
                          }
                        }}
                        disabled={deleting}
                      >
                        {deleting ? (
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        ) : (
                          <Trash2 className="h-3.5 w-3.5" />
                        )}
                        Delete Chat
                      </Button>
                    )}
                  </div>
              </div>

              {/* Error/Success Messages */}
              {error && (
                <div className="mx-4 mt-4 p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
                  <div className="flex items-start gap-2">
                    <XCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-red-700 dark:text-red-300 whitespace-pre-line">
                      {error}
                    </p>
                  </div>
                </div>
              )}

              {success && (
                <div className="mx-4 mt-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                  <div className="flex items-start gap-2">
                    <CheckCircle2 className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                    <p className="text-sm text-green-700 dark:text-green-300">{success}</p>
                  </div>
                </div>
              )}

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {loadingMessages && messages.length === 0 ? (
                  <div className="space-y-3">
                    <div className="flex justify-start">
                      <Skeleton className="h-12 w-2/3 rounded-2xl" />
                    </div>
                    <div className="flex justify-end">
                      <Skeleton className="h-12 w-2/3 rounded-2xl" />
                    </div>
                    <div className="flex justify-start">
                      <Skeleton className="h-12 w-1/2 rounded-2xl" />
                    </div>
                  </div>
                ) : (
                  messages.map((msg, index) => {
                    // #region agent log
                    fetch('http://127.0.0.1:7242/ingest/a9581599-2981-434f-a784-3293e02077df',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'inbox/page.tsx:867',message:'Message rendering entry',data:{messageId:msg.id,type:msg.type,mediaUrl:msg.mediaUrl,mediaMimeType:msg.mediaMimeType,hasAttachments:!!(msg.attachments&&msg.attachments.length>0),attachmentsCount:msg.attachments?.length||0,body:msg.body?.substring(0,50)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
                    // #endregion
                    const isInbound = msg.direction === 'inbound' || msg.direction === 'INBOUND' || msg.direction === 'IN'
                    return (
                      <div
                        key={msg.id}
                        className={cn(
                          'flex animate-in fade-in slide-in-from-bottom-2 duration-300 mb-4',
                          isInbound ? 'justify-start' : 'justify-end'
                        )}
                        style={{ animationDelay: `${index * 50}ms` }}
                      >
                        <div
                          className={cn(
                            'max-w-[75%] p-4 rounded-2xl text-sm shadow-md transition-all hover:shadow-lg',
                            isInbound
                              ? 'bg-blue-50 dark:bg-blue-950/30 text-blue-900 dark:text-blue-100 border-2 border-blue-200 dark:border-blue-800 rounded-tl-none'
                              : 'bg-green-500 dark:bg-green-600 text-white rounded-tr-none shadow-green-500/30'
                          )}
                        >
                          {/* CRITICAL FIX: Check mediaProxyUrl FIRST, then attachments, then placeholder */}
                          {(() => {
                            // PRIORITY 0: Check if message has mediaProxyUrl OR is a media type (new proxy system)
                            const isMediaType = msg.type && MEDIA_TYPES.has(msg.type.toLowerCase())
                            const hasMediaMimeType = msg.mediaMimeType && (
                              msg.mediaMimeType.startsWith('image/') ||
                              msg.mediaMimeType.startsWith('audio/') ||
                              msg.mediaMimeType.startsWith('video/') ||
                              msg.mediaMimeType.includes('pdf') ||
                              msg.mediaMimeType.includes('document')
                            )
                            
                            // CRITICAL FIX: ALWAYS try to render MediaMessage for media types
                            // The proxy will attempt recovery from rawPayload/payload/ExternalEventLog
                            // Only show error if proxy returns 424 after all recovery attempts
                            if (isMediaType || hasMediaMimeType) {
                              const proxyUrl = msg.mediaProxyUrl || `/api/media/messages/${msg.id}`
                              console.log('[INBOX] Rendering MediaMessage for message (proxy will attempt recovery)', {
                                id: msg.id,
                                type: msg.type,
                                hasMediaUrl: !!msg.mediaUrl,
                                mediaUrl: msg.mediaUrl,
                                proxyUrl,
                              })
                              return (
                                <MediaMessage message={{
                                  id: msg.id,
                                  type: msg.type || 'text',
                                  mediaProxyUrl: proxyUrl,
                                  mediaMimeType: msg.mediaMimeType,
                                  mediaFilename: msg.mediaFilename,
                                  body: msg.body,
                                }} />
                              )
                            }
                            
                            // PRIORITY 1: Check attachments
                            if (msg.attachments && msg.attachments.length > 0) {
                            // PHASE 5A: Render attachments (highest priority)
                              return (
                            <div className="space-y-2">
                              {msg.attachments.map((att: any) => {
                                // PHASE 1 DEBUG: Log each attachment
                                console.log('[INBOX-DEBUG] Rendering attachment', {
                                  attachmentId: att.id,
                                  type: att.type,
                                  url: att.url,
                                  mimeType: att.mimeType,
                                  filename: att.filename,
                                })
                                
                                if (att.type === 'image') {
                                  const imageUrl = att.url.startsWith('http') || att.url.startsWith('/') 
                                    ? att.url 
                                    : `/api/media/messages/${msg.id}` // Use main media proxy endpoint
                                  return (
                                    <div key={att.id} className="relative group rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/50">
                                      <img
                                        src={imageUrl}
                                        alt={att.filename || 'Image'}
                                        className="max-w-full h-auto max-h-96 object-contain w-full cursor-pointer hover:opacity-90 transition-opacity"
                                        loading="lazy"
                                        crossOrigin="anonymous"
                                        onError={(e) => {
                                          const target = e.currentTarget
                                          target.onerror = null
                                          target.src = 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="200" height="200"%3E%3Crect fill="%23ddd" width="200" height="200"/%3E%3Ctext fill="%23999" x="50%25" y="50%25" text-anchor="middle" dy=".3em"%3EImage not available%3C/text%3E%3C/svg%3E'
                                        }}
                                      />
                                      <a
                                        href={imageUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity"
                                        title="Open image in new tab"
                                      >
                                        <ImageIcon className="h-8 w-8 text-white" />
                                      </a>
                                    </div>
                                  )
                                } else if (att.type === 'document' || att.type === 'pdf') {
                                  // Use mediaProxyUrl if available, otherwise construct from attachment URL
                                  const docUrl = msg.mediaProxyUrl && msg.mediaRenderable
                                    ? msg.mediaProxyUrl
                                    : (att.url.startsWith('http') || att.url.startsWith('/')
                                        ? att.url
                                        : `/api/media/messages/${msg.id}`) // Use main media proxy endpoint
                                  return (
                                    <a
                                      key={att.id}
                                      href={docUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="flex items-center gap-2 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                                      download={att.filename || undefined}
                                    >
                                      <FileText className="h-5 w-5" />
                                      <span className="text-sm font-medium">{att.filename || 'Document'}</span>
                                    </a>
                                  )
                                } else if (att.type === 'audio') {
                                  // Use mediaProxyUrl if available, otherwise construct from attachment URL
                                  const audioUrl = msg.mediaProxyUrl && msg.mediaRenderable
                                    ? msg.mediaProxyUrl
                                    : (att.url.startsWith('http') || att.url.startsWith('/')
                                        ? att.url
                                        : `/api/media/messages/${msg.id}`) // Use main media proxy endpoint
                                  return (
                                    <div key={att.id} className="bg-slate-50 dark:bg-slate-900/50 rounded-xl p-3 border border-slate-200 dark:border-slate-700">
                                      <AudioMessagePlayer
                                        mediaId={audioUrl}
                                        mimeType={att.mimeType}
                                        messageId={msg.id}
                                        className="w-full"
                                      />
                                    </div>
                                  )
                                } else {
                                  const fileUrl = att.url.startsWith('http') || att.url.startsWith('/')
                                    ? att.url
                                    : `/api/media/messages/${msg.id}` // Use main media proxy endpoint
                                  return (
                                    <a
                                      key={att.id}
                                      href={fileUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="flex items-center gap-2 p-2 bg-slate-100 dark:bg-slate-800 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                                      download={att.filename || undefined}
                                    >
                                      <FileText className="h-5 w-5" />
                                      <span className="text-sm font-medium">{att.filename || 'File'}</span>
                                    </a>
                                  )
                                }
                              })}
                              {/* Show body text if present */}
                              {msg.body && msg.body !== '[audio]' && msg.body !== '[Audio received]' && msg.body !== '[image]' && msg.body !== '[document]' && (
                                <p className="text-sm whitespace-pre-wrap break-words mt-2">{msg.body}</p>
                              )}
                            </div>
                              )
                            }
                            
                            // SIMPLIFIED: Use MediaMessage component for all media types
                            // This provides consistent error handling, loading states, and retry functionality
                            
                            // Use centralized media detection logic
                            const hasMediaResult = hasMedia(msg.type, msg.mediaMimeType)
                            
                            // Check if message has media URL or proxy URL (indicates media message)
                            const hasMediaUrl = !!(msg.mediaUrl || msg.mediaProxyUrl)
                            
                            // Check body for media placeholders
                            const hasMediaPlaceholder = msg.body && /\[(audio|image|video|document|Audio received)\]/i.test(msg.body)
                            
                            // CRITICAL FIX: ALWAYS try to render MediaMessage for media types
                            // The proxy will attempt recovery from rawPayload/payload/ExternalEventLog
                            // Only show error if proxy returns 424 after all recovery attempts
                            // FIX: Also check if type is a media type directly (in case hasMedia fails)
                            const isMediaTypeDirect = msg.type && MEDIA_TYPES.has(msg.type.toLowerCase())
                            
                            // CRITICAL: If there's a media placeholder in body, ALWAYS try to render MediaMessage
                            // This ensures we attempt recovery even if type/mediaUrl are missing
                            if (hasMediaResult || isMediaTypeDirect || msg.mediaProxyUrl || hasMediaPlaceholder) {
                              // Determine message type from MIME type if type field is missing/incorrect
                              const inferredType = detectMediaType(msg.type, msg.mediaMimeType)
                              
                              return (
                                <div className="space-y-2">
                                  <MediaMessage
                                    message={{
                                      id: msg.id,
                                      type: msg.type || inferredType,
                                      mediaProxyUrl: msg.mediaProxyUrl || `/api/media/messages/${msg.id}`,
                                      mediaMimeType: msg.mediaMimeType,
                                      mediaFilename: (msg as any).mediaFilename,
                                      body: msg.body,
                                    }}
                                  />
                                  {msg.body && !['[audio]', '[Audio received]', '[image]', '[video]', '[document:', '[document: file]'].some(placeholder => msg.body?.includes(placeholder)) && (
                                    <p className="text-sm whitespace-pre-wrap break-words">{msg.body}</p>
                                  )}
                                  </div>
                                )
                            }
                            
                            // PART 2: Extract message text from various fields
                            const displayText = getMessageDisplayText(msg)
                            const bodyLower = displayText?.toLowerCase() || ''
                            
                            // #region agent log
                            fetch('http://127.0.0.1:7242/ingest/a9581599-2981-434f-a784-3293e02077df',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'inbox/page.tsx:1300',message:'Fallback text rendering',data:{messageId:msg.id,type:msg.type,mediaUrl:msg.mediaUrl,mediaMimeType:msg.mediaMimeType,hasAttachments:!!(msg.attachments&&msg.attachments.length>0),body:msg.body,bodyLower:bodyLower.substring(0,50)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'H'})}).catch(()=>{});
                            // #endregion
                            
                            if (displayText && typeof displayText === 'string' && displayText.trim() !== '') {
                              // Skip if body looks like a media placeholder (already handled by placeholder check above)
                              if (bodyLower.match(/^\[(audio|document|image|video|media)/i)) {
                                return <p className="text-sm opacity-75">[Media message]</p>
                              }
                              return <p className="text-sm whitespace-pre-wrap break-words">{displayText}</p>
                            }
                            return <p className="text-sm opacity-75">[Media message]</p>
                          })()}
                          {/* #region agent log */}
                          {(() => {
                            const iifeResult = (() => {
                              const bodyHasDocumentPattern = msg.body?.match(/\[document:\s*(.+?)\]/i)
                              const bodyHasImagePattern = msg.body?.match(/\[image\]/i)
                              const bodyHasAudioPattern = msg.body?.match(/\[(audio|Audio received)\]/i)
                              const bodyHasVideoPattern = msg.body?.match(/\[video\]/i)
                              const hasMediaPlaceholder = !!(bodyHasDocumentPattern || bodyHasImagePattern || bodyHasAudioPattern || bodyHasVideoPattern)
                              if (hasMediaPlaceholder && !msg.mediaUrl && (!msg.attachments || msg.attachments.length === 0)) {
                                return 'HAS_PLACEHOLDER_JSX'
                              }
                              return 'NO_PLACEHOLDER'
                            })()
                            if (iifeResult === 'HAS_PLACEHOLDER_JSX') {
                              fetch('http://127.0.0.1:7242/ingest/a9581599-2981-434f-a784-3293e02077df',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'inbox/page.tsx:1336',message:'IIFE should have returned placeholder JSX',data:{messageId:msg.id,body:msg.body?.substring(0,50)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'AY'})}).catch(()=>{});
                            }
                            return null
                          })()}
                          {/* #endregion */}
                          <div className="flex items-center gap-1 mt-1">
                            <p
                              className={cn(
                                'text-xs',
                                isInbound
                                  ? 'text-slate-500 dark:text-slate-400'
                                  : 'text-primary-foreground/70'
                              )}
                            >
                              {formatMessageTime(msg.createdAt)}
                            </p>
                            {!isInbound && (
                              <div 
                                className="flex items-center" 
                                title={
                                  msg.status === 'READ' ? 'Read' :
                                  msg.status === 'DELIVERED' ? 'Delivered' :
                                  msg.status === 'SENT' ? 'Sent' :
                                  msg.status === 'FAILED' ? 'Failed' : 'Pending'
                                }
                              >
                                {msg.status === 'READ' ? (
                                  <CheckCheck className="h-3 w-3 text-blue-500" />
                                ) : msg.status === 'DELIVERED' ? (
                                  <CheckCheck className="h-3 w-3 text-gray-400" />
                                ) : msg.status === 'SENT' ? (
                                  <CheckCircle2 className="h-3 w-3 text-gray-400" />
                                ) : msg.status === 'FAILED' ? (
                                  <XCircle className="h-3 w-3 text-red-500" />
                                ) : (
                                  <Clock className="h-3 w-3 text-gray-400" />
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    )
                  })
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Input */}
              <div className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
                {/* File Preview */}
                {selectedFile && (
                  <div className="mb-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg flex items-center justify-between">
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <Paperclip className="h-4 w-4 text-slate-500 flex-shrink-0" />
                      <span className="text-sm text-slate-700 dark:text-slate-300 truncate">
                        {selectedFile.name}
                      </span>
                      <span className="text-xs text-slate-500">
                        ({(selectedFile.size / 1024).toFixed(1)} KB)
                      </span>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setSelectedFile(null)
                        if (fileInputRef.current) {
                          fileInputRef.current.value = ''
                        }
                      }}
                      className="h-6 w-6 p-0"
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}

                {/* Upload Progress */}
                {uploading && uploadProgress > 0 && (
                  <div className="mb-3">
                    <div className="h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary transition-all duration-300"
                        style={{ width: `${uploadProgress}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                      Uploading... {uploadProgress}%
                    </p>
                  </div>
                )}

                <form onSubmit={handleSendMessage} className="flex gap-2 items-end">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt"
                    onChange={handleFileSelect}
                    className="hidden"
                    disabled={sending || uploading}
                  />
                  
                  <Button
                    type="button"
                    variant="outline"
                    size="default"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={sending || uploading}
                    className="h-[44px] px-3"
                    title="Attach file"
                  >
                    <Paperclip className="h-4 w-4" />
                  </Button>

                  <Textarea
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={selectedFile ? "Add a caption (optional)..." : "Type your message..."}
                    className="flex-1 min-h-[44px] max-h-32 text-sm resize-none"
                    disabled={sending || uploading}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault()
                        if ((newMessage.trim() || selectedFile) && !sending && !uploading) {
                          handleSendMessage(e as any)
                        }
                      }
                    }}
                    rows={1}
                  />
                  <Button 
                    type="submit" 
                    disabled={(!newMessage.trim() && !selectedFile) || sending || uploading} 
                    size="default"
                    className="gap-2 h-[44px] px-4"
                  >
                    {(sending || uploading) ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    <span className="hidden sm:inline">Send</span>
                  </Button>
                </form>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
                  {selectedFile 
                    ? 'File ready to send. Add a caption or click Send.'
                    : 'Press Enter to send, Shift+Enter for new line, or attach a file'}
                </p>
              </div>
            </>
          ) : (
            <EmptyState
              icon={MessageCircle}
              title="Select a conversation"
              description="Choose a conversation from the sidebar to view messages."
              className="flex-1"
            />
          )}
        </BentoCard>
      </div>
      
      {/* STEP 0: Build stamp for deployment verification */}
      {buildInfo && (
        <div className="fixed bottom-2 right-2 text-xs text-slate-400 dark:text-slate-600 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded z-50">
          Build: {buildInfo.buildId || 'unknown'}
        </div>
      )}
    </MainLayout>
  )
}

export default function InboxPage() {
  return (
    <Suspense fallback={
      <MainLayout>
        <div className="flex items-center justify-center h-screen">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading inbox...</p>
          </div>
        </div>
      </MainLayout>
    }>
      <InboxPageContent />
    </Suspense>
  )
}
