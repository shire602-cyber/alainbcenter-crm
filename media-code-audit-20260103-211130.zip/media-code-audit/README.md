# Media Code Audit - Complete Codebase

This archive contains ALL code related to:
- Media handling (images, PDFs, audio, video)
- WhatsApp media integration
- Media proxy and storage
- Media recovery mechanisms
- Frontend media components

## File Structure

### API Routes
- `/src/app/api/media/` - Media proxy endpoints
- `/src/app/api/webhooks/whatsapp/` - WhatsApp webhook handler
- `/src/app/api/inbox/` - Inbox API (includes media handling)
- `/src/app/api/leads/` - Leads API (includes media handling)
- `/src/app/api/upload/` - Media upload endpoint
- `/src/app/api/admin/backfill-media-ids/` - Media ID backfill
- `/src/app/api/debug/media/` - Media debugging endpoints

### Libraries
- `/src/lib/media/` - Core media utilities
  - `whatsappMedia.ts` - WhatsApp Media API client
  - `extractMediaId.ts` - Media ID extraction
  - `mediaTypeDetection.ts` - Media type detection
  - `storage.ts` - Media caching/storage
- `/src/lib/whatsapp-media-upload.ts` - Media upload to Meta
- `/src/lib/whatsapp*.ts` - WhatsApp integration files
- `/src/lib/inbound/autoMatchPipeline.ts` - Inbound message processing (includes media)

### Components
- `/src/components/inbox/MediaMessage.tsx` - Main media message component
- `/src/components/inbox/AudioMessagePlayer.tsx` - Audio player component
- `/src/app/inbox/page.tsx` - Inbox page (media rendering)
- `/src/components/leads/ConversationWorkspace.tsx` - Conversation view (media)

### Scripts & Tests
- `/scripts/*media*.ts` - Media testing/verification scripts
- `/e2e/*media*.spec.ts` - End-to-end media tests

## Current Issue

Recent media messages are showing "[Media message]" placeholders because:
- `providerMediaId` is NULL
- `mediaUrl` is NULL  
- `rawPayload` is NULL
- `payload` is NULL

This means the webhook extraction is failing and no recovery data is being stored.

## Key Files to Review

1. **Webhook Handler**: `src/app/api/webhooks/whatsapp/route.ts`
   - Extracts media info from webhook
   - Passes to pipeline

2. **Pipeline**: `src/lib/inbound/autoMatchPipeline.ts`
   - Stores media data in database
   - Fallback extraction from rawPayload

3. **Media Proxy**: `src/app/api/media/messages/[id]/route.ts`
   - Fetches media from WhatsApp
   - Recovery mechanisms (PRIORITY A-E)

4. **Frontend**: `src/app/inbox/page.tsx`
   - Renders media messages
   - Uses MediaMessage component

