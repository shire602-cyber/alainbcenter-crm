/**
 * Unified Media ID Extraction
 * 
 * Extracts providerMediaId (Meta Graph API media ID) from WhatsApp webhook messages
 * Uses WhatsApp's documented standard: message.{type}.id
 * 
 * This replaces the complex extraction logic scattered across the webhook handler
 */

export interface ExtractedMediaInfo {
  providerMediaId: string | null
  mediaMimeType: string | null
  filename: string | null
  mediaSize: number | null
  mediaSha256: string | null
  caption: string | null
}

/**
 * Extract media information from WhatsApp webhook message
 * 
 * WhatsApp standard structure:
 * - message.image.id
 * - message.audio.id
 * - message.document.id
 * - message.video.id
 * 
 * @param message - WhatsApp webhook message object
 * @param messageType - Message type (image, audio, document, video)
 * @returns Extracted media information
 */
export function extractMediaInfo(
  message: any,
  messageType: string
): ExtractedMediaInfo {
  const result: ExtractedMediaInfo = {
    providerMediaId: null,
    mediaMimeType: null,
    filename: null,
    mediaSize: null,
    mediaSha256: null,
    caption: null,
  }

  // Get the media object based on type
  const mediaObject = message[messageType]
  if (!mediaObject) {
    console.warn(`[MEDIA-EXTRACTION] No ${messageType} object found in message`, {
      messageId: message.id,
      messageType,
      messageKeys: Object.keys(message),
    })
    return result
  }

  // CRITICAL: Log the media object structure for debugging
  console.log(`🔍 [MEDIA-EXTRACTION] Extracting from ${messageType} object:`, {
    messageId: message.id,
    messageType,
    mediaObjectKeys: Object.keys(mediaObject),
    hasId: !!mediaObject.id,
    idValue: mediaObject.id,
    idType: typeof mediaObject.id,
  })

  // WhatsApp standard: message.{type}.id is the media ID
  // Try multiple possible field names for robustness
  const mediaId = mediaObject.id || 
                 mediaObject.media_id || 
                 mediaObject.mediaId ||
                 mediaObject['id'] ||
                 null
  
  if (mediaId) {
    const mediaIdStr = String(mediaId).trim()
    // FIX: Validate format (non-empty, no spaces, reasonable length, not "undefined"/"null")
    if (mediaIdStr !== '' && 
        mediaIdStr.length > 0 && 
        mediaIdStr.length < 500 && // Reasonable max length for WhatsApp media IDs
        !mediaIdStr.includes(' ') && // No spaces
        mediaIdStr !== 'undefined' && 
        mediaIdStr !== 'null') {
      result.providerMediaId = mediaIdStr
      console.log(`✅ [MEDIA-EXTRACTION] Extracted providerMediaId: ${result.providerMediaId}`)
    } else {
      console.warn(`⚠️ [MEDIA-EXTRACTION] Invalid media ID format extracted: ${mediaIdStr}`, {
        length: mediaIdStr.length,
        hasSpaces: mediaIdStr.includes(' '),
        isUndefined: mediaIdStr === 'undefined',
        isNull: mediaIdStr === 'null',
      })
    }
  } else {
    console.warn(`⚠️ [MEDIA-EXTRACTION] No media ID found in ${messageType} object`, {
      messageId: message.id,
      messageType,
      mediaObjectKeys: Object.keys(mediaObject),
      mediaObject: JSON.stringify(mediaObject),
    })
  }

  // Extract MIME type (with fallbacks for different field names)
  result.mediaMimeType =
    mediaObject.mime_type ||
    mediaObject.mimeType ||
    getDefaultMimeType(messageType)

  // Extract filename (for documents)
  result.filename = mediaObject.filename || null

  // Extract file size
  if (mediaObject.file_size) {
    result.mediaSize = parseInt(String(mediaObject.file_size))
  } else if (mediaObject.fileSize) {
    result.mediaSize = parseInt(String(mediaObject.fileSize))
  }

  // Extract SHA256 hash
  result.mediaSha256 = mediaObject.sha256 || mediaObject.sha_256 || null

  // Extract caption (for images/videos)
  result.caption = mediaObject.caption || null

  // Log warning if media ID is missing (data quality issue)
  if (!result.providerMediaId) {
    console.warn(`[MEDIA-EXTRACTION] Missing media ID for ${messageType} message`, {
      messageId: message.id,
      messageType,
      mediaObjectKeys: Object.keys(mediaObject),
      mediaObject: JSON.stringify(mediaObject),
    })
  }

  return result
}

/**
 * Get default MIME type for a message type
 */
function getDefaultMimeType(messageType: string): string {
  switch (messageType) {
    case 'image':
      return 'image/jpeg'
    case 'audio':
      return 'audio/ogg'
    case 'document':
      return 'application/pdf'
    case 'video':
      return 'video/mp4'
    default:
      return 'application/octet-stream'
  }
}

/**
 * Detect message type from webhook message object
 * Checks for media objects first, then falls back to message.type
 * 
 * WhatsApp sometimes sends media messages with type='text' but with media objects
 */
export function detectMediaType(message: any): string {
  // Check for media objects first (most reliable)
  if (message.image) return 'image'
  if (message.audio) return 'audio'
  if (message.document) return 'document'
  if (message.video) return 'video'
  
  // Fall back to message.type
  return message.type || 'text'
}

