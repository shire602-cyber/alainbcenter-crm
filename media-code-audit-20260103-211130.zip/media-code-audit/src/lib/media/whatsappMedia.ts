/**
 * WHATSAPP MEDIA HELPER
 * 
 * Helper functions for fetching WhatsApp media from Meta Graph API
 * Handles authentication, URL fetching, and streaming with retry logic
 */

export interface WhatsAppMediaInfo {
  url: string
  mimeType: string
  fileSize?: number
  fileName?: string
}

export class MediaExpiredError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'MediaExpiredError'
  }
}

export class MediaRateLimitError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'MediaRateLimitError'
  }
}

/**
 * Get WhatsApp media download URL from Meta Graph API with retry logic
 * @param mediaId - WhatsApp media ID (stored in Message.providerMediaId)
 * @param accessToken - WhatsApp access token
 * @param retries - Number of retry attempts (default: 3)
 * @returns Media download URL and metadata
 */
export async function getWhatsAppDownloadUrl(
  mediaId: string,
  accessToken: string,
  retries: number = 3
): Promise<WhatsAppMediaInfo> {
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      // FIX: Add timeout handling (30 seconds)
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 30000)
      
      const response = await fetch(
        `https://graph.facebook.com/v21.0/${mediaId}`,
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
          signal: controller.signal,
        }
      )
      
      clearTimeout(timeoutId)

      // Handle expired media (410) - don't retry
      if (response.status === 410) {
        throw new MediaExpiredError(`Media ID ${mediaId} has expired`)
      }

      // Handle rate limiting (429) - retry with backoff
      if (response.status === 429) {
        if (attempt < retries) {
          const backoffDelay = 1000 * attempt // Exponential backoff: 1s, 2s, 3s
          console.warn(`[MEDIA] Rate limited, retrying in ${backoffDelay}ms (attempt ${attempt}/${retries})`)
          await new Promise(resolve => setTimeout(resolve, backoffDelay))
          continue
        }
        throw new MediaRateLimitError(`Rate limited after ${retries} attempts`)
      }

      if (!response.ok) {
        const error = await response.json().catch(() => ({}))
        const errorMessage = error.error?.message || `Failed to fetch media URL: ${response.statusText}`
        
        // Retry on 5xx errors (server errors)
        if (response.status >= 500 && attempt < retries) {
          const backoffDelay = 1000 * attempt
          console.warn(`[MEDIA] Server error ${response.status}, retrying in ${backoffDelay}ms (attempt ${attempt}/${retries})`)
          await new Promise(resolve => setTimeout(resolve, backoffDelay))
          continue
        }
        
        throw new Error(errorMessage)
      }

      const data = await response.json()
      
      if (!data.url) {
        throw new Error('Media URL not found in Meta response')
      }

      return {
        url: data.url,
        mimeType: data.mime_type || 'application/octet-stream',
        fileSize: data.file_size ? parseInt(data.file_size) : undefined,
        fileName: data.filename || undefined,
      }
    } catch (error: any) {
      // Don't retry on MediaExpiredError or MediaRateLimitError (already handled above)
      if (error instanceof MediaExpiredError || error instanceof MediaRateLimitError) {
        throw error
      }
      
      // Retry on network errors (TypeError, ECONNRESET, ETIMEDOUT, AbortError for timeout)
      if (attempt < retries && (
        error.name === 'TypeError' || 
        error.code === 'ECONNRESET' || 
        error.code === 'ETIMEDOUT' ||
        error.name === 'AbortError'
      )) {
        const backoffDelay = 1000 * attempt
        console.warn(`[MEDIA] Network error: ${error.message}, retrying in ${backoffDelay}ms (attempt ${attempt}/${retries})`)
        await new Promise(resolve => setTimeout(resolve, backoffDelay))
        continue
      }
      
      // Last attempt or non-retryable error
      throw error
    }
  }
  
  throw new Error('Max retries exceeded')
}

/**
 * Fetch WhatsApp media stream with Range support and retry logic
 * @param mediaUrl - Download URL from getWhatsAppDownloadUrl
 * @param accessToken - WhatsApp access token
 * @param rangeHeader - Optional Range header for partial content requests
 * @param retries - Number of retry attempts (default: 3)
 * @returns Response with streamable body
 * 
 * CRITICAL: Meta download URLs often require Authorization header AND may redirect
 */
export async function fetchWhatsAppMediaStream(
  mediaUrl: string,
  accessToken: string,
  rangeHeader?: string | null,
  retries: number = 3
): Promise<Response> {
  const headers: HeadersInit = {
    Authorization: `Bearer ${accessToken}`, // CRITICAL: Meta requires token on download URL too
  }

  // Forward Range header for audio/video streaming (seeking support)
  if (rangeHeader) {
    headers['Range'] = rangeHeader
  }

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      // FIX: Add timeout handling (30 seconds)
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 30000)
      
      // CRITICAL: Follow redirects and include Authorization on redirects too
      let response = await fetch(mediaUrl, {
        headers,
        redirect: 'follow', // Follow redirects automatically
        signal: controller.signal,
      })
      
      clearTimeout(timeoutId)

      // If we got a redirect, ensure we follow it with auth header
      // (fetch with redirect: 'follow' should handle this, but be explicit)
      if (response.redirected && response.url !== mediaUrl) {
        // Re-fetch the final URL with auth (in case redirect didn't preserve headers)
        response = await fetch(response.url, {
          headers,
          redirect: 'follow',
        })
      }

      // Handle expired media (410) - don't retry
      if (response.status === 410) {
        throw new MediaExpiredError(`Media URL has expired: ${mediaUrl}`)
      }

      // Handle rate limiting (429) - retry with backoff
      if (response.status === 429) {
        if (attempt < retries) {
          const backoffDelay = 1000 * attempt
          console.warn(`[MEDIA] Rate limited on download, retrying in ${backoffDelay}ms (attempt ${attempt}/${retries})`)
          await new Promise(resolve => setTimeout(resolve, backoffDelay))
          continue
        }
        throw new MediaRateLimitError(`Rate limited after ${retries} attempts`)
      }

      // Retry on 5xx errors (server errors)
      if (response.status >= 500 && attempt < retries) {
        const backoffDelay = 1000 * attempt
        console.warn(`[MEDIA] Server error ${response.status} on download, retrying in ${backoffDelay}ms (attempt ${attempt}/${retries})`)
        await new Promise(resolve => setTimeout(resolve, backoffDelay))
        continue
      }

      if (!response.ok) {
        const errorText = await response.text().catch(() => response.statusText)
        throw new Error(`Failed to download media: ${response.status} ${errorText}`)
      }

      return response
    } catch (error: any) {
      // Don't retry on MediaExpiredError or MediaRateLimitError
      if (error instanceof MediaExpiredError || error instanceof MediaRateLimitError) {
        throw error
      }
      
      // Retry on network errors (including timeout/AbortError)
      if (attempt < retries && (
        error.name === 'TypeError' || 
        error.code === 'ECONNRESET' || 
        error.code === 'ETIMEDOUT' ||
        error.name === 'AbortError'
      )) {
        const backoffDelay = 1000 * attempt
        console.warn(`[MEDIA] Network error on download: ${error.message}, retrying in ${backoffDelay}ms (attempt ${attempt}/${retries})`)
        await new Promise(resolve => setTimeout(resolve, backoffDelay))
        continue
      }
      
      // Last attempt or non-retryable error
      throw error
    }
  }
  
  throw new Error('Max retries exceeded')
}

/**
 * Get WhatsApp access token from environment or database
 * @returns Access token or null
 */
export async function getWhatsAppAccessToken(): Promise<string | null> {
  // Try database first (Integration model)
  try {
    const { prisma } = await import('@/lib/prisma')
    const integration = await prisma.integration.findUnique({
      where: { name: 'whatsapp' },
    })

    if (integration?.config) {
      try {
        const config = typeof integration.config === 'string'
          ? JSON.parse(integration.config)
          : integration.config
        
        // Check multiple possible keys for access token
        const token = config.accessToken || 
                     config.access_token || 
                     config.token || 
                     config.whatsappToken || 
                     config.metaToken
        
        if (token) {
          return token
        }
      } catch (parseError: any) {
        // Only log errors in development
        if (process.env.NODE_ENV === 'development') {
          console.error('[TOKEN-DEBUG] Failed to parse config:', parseError.message)
        }
      }
    }

    if (integration?.accessToken || integration?.apiKey) {
      const token = integration.accessToken || integration.apiKey
      return token
    }
  } catch (error: any) {
    // Only log errors in development
    if (process.env.NODE_ENV === 'development') {
      console.error('[TOKEN-DEBUG] Database query failed:', error.message)
    }
    // Fallback to env var
  }

  // Fallback to environment variable
  const envToken = process.env.WHATSAPP_ACCESS_TOKEN || process.env.META_ACCESS_TOKEN
  if (envToken) {
    return envToken
  }
  
  // Only log errors in development
  if (process.env.NODE_ENV === 'development') {
    console.error('[TOKEN-DEBUG] No token found in database or environment')
  }
  return null
}


