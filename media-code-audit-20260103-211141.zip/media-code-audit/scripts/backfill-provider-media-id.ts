#!/usr/bin/env tsx
/**
 * Backfill script for old messages missing providerMediaId
 * 
 * Finds messages where type in (image,audio,document,video) AND providerMediaId is null
 * Attempts to recover from ExternalEventLog by searching webhook payloads
 * Updates message rows with providerMediaId, mediaMimeType, mediaFilename
 */

import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

interface RecoveryResult {
  messageId: number
  type: string
  recovered: boolean
  providerMediaId: string | null
  source: 'eventLog' | 'rawPayload' | 'payload' | 'mediaUrl' | 'failed'
  error?: string
}

async function recoverMediaId(message: any): Promise<RecoveryResult> {
  const result: RecoveryResult = {
    messageId: message.id,
    type: message.type || 'unknown',
    recovered: false,
    providerMediaId: null,
    source: 'failed',
  }

  // PRIORITY 1: Check rawPayload
  if (message.rawPayload) {
    try {
      const rawPayload = typeof message.rawPayload === 'string' ? JSON.parse(message.rawPayload) : message.rawPayload
      const mediaId = rawPayload.audio?.id || rawPayload.image?.id || rawPayload.document?.id || rawPayload.video?.id
      if (mediaId) {
        result.providerMediaId = String(mediaId).trim()
        result.recovered = true
        result.source = 'rawPayload'
        return result
      }
    } catch (e) {
      // Invalid JSON
    }
  }

  // PRIORITY 2: Check payload
  if (message.payload) {
    try {
      const payload = typeof message.payload === 'string' ? JSON.parse(message.payload) : message.payload
      const mediaId = payload?.media?.id || payload?.mediaUrl
      if (mediaId && typeof mediaId === 'string' && !mediaId.startsWith('http')) {
        result.providerMediaId = mediaId.trim()
        result.recovered = true
        result.source = 'payload'
        return result
      }
    } catch (e) {
      // Invalid JSON
    }
  }

  // PRIORITY 3: Check mediaUrl (if it looks like a media ID)
  if (message.mediaUrl && !message.mediaUrl.startsWith('http') && !message.mediaUrl.startsWith('/')) {
    result.providerMediaId = message.mediaUrl.trim()
    result.recovered = true
    result.source = 'mediaUrl'
    return result
  }

  // PRIORITY 4: Try ExternalEventLog
  if (message.providerMessageId) {
    try {
      // Search by providerMessageId
      const eventLog = await prisma.externalEventLog.findFirst({
        where: {
          provider: 'whatsapp',
          payload: {
            contains: message.providerMessageId,
          },
        },
        select: { id: true, payload: true },
        orderBy: { receivedAt: 'desc' },
      })

      if (eventLog?.payload) {
        try {
          const webhookPayload = typeof eventLog.payload === 'string' ? JSON.parse(eventLog.payload) : eventLog.payload
          
          // Check extractedMediaUrl first
          if (webhookPayload.extractedMediaUrl) {
            result.providerMediaId = String(webhookPayload.extractedMediaUrl).trim()
            result.recovered = true
            result.source = 'eventLog'
            return result
          }
          
          // Extract from message structure
          let messages: any[] | null = null
          if (webhookPayload.entry?.[0]?.changes?.[0]?.value?.messages) {
            messages = webhookPayload.entry[0].changes[0].value.messages
          } else if (webhookPayload.message) {
            messages = [webhookPayload.message]
          }
          
          if (messages && Array.isArray(messages)) {
            const matchingMessage = messages.find((m: any) => m?.id === message.providerMessageId) || messages[0]
            if (matchingMessage) {
              const mediaId = matchingMessage.audio?.id || matchingMessage.image?.id || matchingMessage.document?.id || matchingMessage.video?.id
              if (mediaId) {
                result.providerMediaId = String(mediaId).trim()
                result.recovered = true
                result.source = 'eventLog'
                return result
              }
            }
          }
        } catch (e) {
          result.error = `Failed to parse ExternalEventLog payload: ${e}`
        }
      }
    } catch (e) {
      result.error = `ExternalEventLog query failed: ${e}`
    }
  }

  return result
}

async function main() {
  console.log('🔍 Finding media messages without providerMediaId...\n')

  // Find messages that need recovery
  const messages = await prisma.message.findMany({
    where: {
      type: { in: ['image', 'audio', 'document', 'video'] },
      providerMediaId: null,
      channel: 'whatsapp',
    },
    select: {
      id: true,
      type: true,
      mediaUrl: true,
      mediaMimeType: true,
      mediaFilename: true,
      payload: true,
      rawPayload: true,
      providerMessageId: true,
    },
    orderBy: { createdAt: 'desc' },
    take: 1000, // Process in batches
  })

  console.log(`Found ${messages.length} messages to process\n`)

  const results: RecoveryResult[] = []
  let recovered = 0
  let failed = 0

  for (const message of messages) {
    const result = await recoverMediaId(message)
    results.push(result)

    if (result.recovered && result.providerMediaId) {
      try {
        // Update message with recovered providerMediaId
        await prisma.message.update({
          where: { id: message.id },
          data: {
            providerMediaId: result.providerMediaId,
            // Also update mediaUrl for backward compatibility
            mediaUrl: result.providerMediaId,
          },
        })
        recovered++
        console.log(`✅ Recovered message ${message.id} (${result.type}): ${result.providerMediaId} from ${result.source}`)
      } catch (e: any) {
        failed++
        console.error(`❌ Failed to update message ${message.id}: ${e.message}`)
        result.error = e.message
      }
    } else {
      failed++
      console.log(`⚠️  Could not recover message ${message.id} (${result.type})`)
    }
  }

  console.log('\n📊 Summary:')
  console.log(`  Total messages: ${messages.length}`)
  console.log(`  Recovered: ${recovered}`)
  console.log(`  Failed: ${failed}`)
  console.log(`  Recovery rate: ${((recovered / messages.length) * 100).toFixed(1)}%`)

  // Print failed message IDs
  const failedIds = results.filter(r => !r.recovered).map(r => r.messageId)
  if (failedIds.length > 0) {
    console.log(`\n❌ Messages still missing metadata (${failedIds.length}):`)
    console.log(`   ${failedIds.slice(0, 20).join(', ')}${failedIds.length > 20 ? '...' : ''}`)
  }

  await prisma.$disconnect()
}

main().catch(console.error)

