import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUserApi } from '@/lib/authApi'
import { prisma } from '@/lib/prisma'

/**
 * POST /api/admin/backfill-media-ids
 * Backfill mediaUrl and mediaMimeType for existing messages where mediaUrl is null
 * ADMIN ONLY
 */
export async function POST(req: NextRequest) {
  try {
    // Verify admin access
    const user = await getCurrentUserApi()
    if (!user || user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    console.log('[BACKFILL] Starting media ID backfill...')

    // Find messages with media type but null providerMediaId or mediaUrl
    const messagesToBackfill = await prisma.message.findMany({
      where: {
        AND: [
          {
            OR: [
              { type: { in: ['audio', 'image', 'video', 'document'] } },
              { mediaMimeType: { not: null } },
            ],
          },
          {
            OR: [
              { providerMediaId: null },
              { mediaUrl: null },
            ],
          },
        ],
      },
      select: {
        id: true,
        type: true,
        mediaMimeType: true,
        rawPayload: true,
        payload: true,
      },
      take: 1000, // Limit to prevent timeout
    })

    console.log(`[BACKFILL] Found ${messagesToBackfill.length} messages to backfill`)

    if (messagesToBackfill.length === 0) {
      return NextResponse.json({
        updated: 0,
        message: 'No messages need backfilling',
      })
    }

    let updated = 0
    let cannotBackfill = 0

    for (const message of messagesToBackfill) {
      let mediaId: string | null = null
      let mimeType: string | null = message.mediaMimeType || null
      let filename: string | null = null
      let mediaSize: number | null = null

      // Try to extract from rawPayload (full webhook payload)
      if (message.rawPayload) {
        try {
          const rawPayload = typeof message.rawPayload === 'string' 
            ? JSON.parse(message.rawPayload) 
            : message.rawPayload

          // WhatsApp webhook structure: message.audio.id, message.image.id, etc.
          const mediaObject = message.type === 'audio' ? rawPayload.audio :
                             message.type === 'image' ? rawPayload.image :
                             message.type === 'video' ? rawPayload.video :
                             message.type === 'document' ? rawPayload.document : null

          if (mediaObject?.id) {
            mediaId = mediaObject.id
            mimeType = mediaObject.mime_type || mimeType
            // FIX #10: Extract filename and file_size (check all possible field names)
            filename = mediaObject.filename || null
            // Try multiple field names for file size
            if (mediaObject.file_size) {
              mediaSize = parseInt(String(mediaObject.file_size))
            } else if (mediaObject.fileSize) {
              mediaSize = parseInt(String(mediaObject.fileSize))
            } else if (mediaObject.size) {
              mediaSize = parseInt(String(mediaObject.size))
            } else if (mediaObject.file_size_bytes) {
              mediaSize = parseInt(String(mediaObject.file_size_bytes))
            }
            // Validate parsed size
            if (mediaSize !== null && (isNaN(mediaSize) || mediaSize <= 0)) {
              mediaSize = null
            }
          }
        } catch (e) {
          // rawPayload parse error - skip
        }
      }

      // Try to extract from payload (provider-specific metadata)
      if (!mediaId && message.payload) {
        try {
          const payload = typeof message.payload === 'string'
            ? JSON.parse(message.payload)
            : message.payload

          if (payload.mediaId || payload.media_id || payload.id) {
            mediaId = payload.mediaId || payload.media_id || payload.id
          }
        } catch (e) {
          // payload parse error - skip
        }
      }

      if (mediaId) {
        try {
          // CRITICAL FIX: Update BOTH providerMediaId AND mediaUrl
          // providerMediaId is checked first by media proxy, so it's critical
          const updateData: any = {
            providerMediaId: mediaId, // CRITICAL: Set providerMediaId (checked first by proxy)
            mediaUrl: mediaId, // Backward compatibility
            mediaMimeType: mimeType,
          }
          if (filename) {
            updateData.mediaFilename = filename
          }
          if (mediaSize && mediaSize > 0) {
            updateData.mediaSize = mediaSize
          }
          
          await prisma.message.update({
            where: { id: message.id },
            data: updateData,
          })
          updated++
          console.log(`[BACKFILL] Updated message ${message.id} with providerMediaId=${mediaId}, filename=${filename || 'none'}, size=${mediaSize || 'none'}`)
        } catch (e: any) {
          console.error(`[BACKFILL] Failed to update message ${message.id}:`, e.message)
        }
      } else {
        cannotBackfill++
        console.log(`[BACKFILL] Cannot backfill message ${message.id}: no media ID in rawPayload or payload`)
      }
    }

    const result = {
      total: messagesToBackfill.length,
      updated,
      cannotBackfill,
      message: cannotBackfill > 0
        ? `Updated ${updated} messages. ${cannotBackfill} messages cannot be backfilled because media ID was never stored in DB.`
        : `Updated ${updated} messages.`,
    }

    console.log(`[BACKFILL] Backfill complete:`, result)

    return NextResponse.json(result)
  } catch (error: any) {
    console.error('[BACKFILL] Error:', error)
    return NextResponse.json(
      { error: error.message },
      { status: 500 }
    )
  }
}

