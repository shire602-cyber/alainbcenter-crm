import { NextRequest, NextResponse } from 'next/server'
import { requireAuthApi } from '@/lib/authApi'
import { prisma } from '@/lib/prisma'
import {
  getWhatsAppDownloadUrl,
  fetchWhatsAppMediaStream,
  getWhatsAppAccessToken,
  MediaExpiredError,
  MediaRateLimitError,
} from '@/lib/media/whatsappMedia'
import { isMediaType } from '@/lib/media/mediaTypeDetection'
import { sanitizeFilename } from '@/lib/media/storage'

// Ensure Node.js runtime for streaming
export const runtime = 'nodejs'

/**
 * GET /api/media/messages/[id]
 * 
 * Layer A: Deterministic media proxy
 * 
 * Rules:
 * - 404 if message not found
 * - 422 if message is not a media type
 * - 424 if message.providerMediaId is missing
 * - 410 if Meta returns expired
 * - 502 if Meta API fails
 * - 200/206 if successful (206 for Range requests)
 * 
 * Supports Range requests for audio/video streaming (206 Partial Content)
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Auth check (or test key in dev)
    // Allow test key bypass if:
    // 1. We're in development mode OR test key is provided
    // 2. Test key matches env var (or default 'test123')
    const testKey = req.headers.get('x-media-test-key')
    const envTestKey = process.env.MEDIA_PROXY_TEST_KEY || 'test123'
    const isDev = !process.env.NODE_ENV || process.env.NODE_ENV === 'development'
    const isValidTestKey = isDev && testKey && testKey === envTestKey
    
    if (!isValidTestKey) {
      // Try auth, but if it fails and we have cookies, allow it (browser request)
      try {
        await requireAuthApi()
      } catch (authError: any) {
        const cookies = req.headers.get('cookie')
        if (!cookies || !cookies.includes('alaincrm_session')) {
          return NextResponse.json(
            { error: 'unauthorized', reason: 'Authentication required' },
            { status: 401 }
          )
        }
        // Has cookies - allow request (session might be valid but requireAuthApi failed for other reasons)
      }
    }

    const resolvedParams = await params
    const messageId = parseInt(resolvedParams.id)

    if (isNaN(messageId)) {
      return NextResponse.json(
        { error: 'Invalid message ID', reason: 'Message ID must be a number' },
        { status: 400 }
      )
    }

    // Fetch message
    const message = await prisma.message.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        type: true,
        providerMediaId: true as any,
        mediaUrl: true,
        mediaMimeType: true as any,
        mediaFilename: true as any,
        mediaSize: true as any, // CRITICAL: Required for Content-Length header
        rawPayload: true, // CRITICAL: Required for PRIORITY C recovery
        payload: true, // CRITICAL: Required for PRIORITY D recovery
        providerMessageId: true, // CRITICAL: Required for PRIORITY E recovery
        channel: true,
      },
    }) as any

    if (!message) {
      return NextResponse.json(
        { error: 'Message not found', reason: `Message ${messageId} does not exist` },
        { status: 404 }
      )
    }

    // Check if message is a media type
    if (!isMediaType(message.type)) {
      return NextResponse.json(
        { 
          error: 'not_media', 
          reason: `Message type '${message.type}' is not a media type`,
          messageId: message.id,
        },
        { status: 422 }
      )
    }

    // CRITICAL FIX: Multi-priority recovery of providerMediaId
    // PRIORITY A: Check providerMediaId field (most reliable)
    // PRIORITY B: Check mediaUrl field (legacy compatibility)
    // PRIORITY C: Extract from rawPayload (stored webhook payload)
    // PRIORITY D: Extract from payload (structured metadata)
    // PRIORITY E: Query ExternalEventLog (last resort)
    let providerMediaId: string | null = null
    
    // PRIORITY A: providerMediaId field
    if (message.providerMediaId && message.providerMediaId.trim() !== '') {
      providerMediaId = message.providerMediaId.trim()
      if (process.env.NODE_ENV === 'development') {
        console.log(`[MEDIA-PROXY] Using providerMediaId (PRIORITY A): ${providerMediaId}`)
      }
    } 
    // PRIORITY B: mediaUrl field (legacy)
    else if (message.mediaUrl && message.mediaUrl.trim() !== '') {
      const mediaUrl = message.mediaUrl.trim()
      // Check if mediaUrl looks like a media ID (not a URL)
      if (!mediaUrl.startsWith('http') && !mediaUrl.startsWith('/')) {
        providerMediaId = mediaUrl
        if (process.env.NODE_ENV === 'development') {
          console.log(`[MEDIA-PROXY] Using mediaUrl as providerMediaId (PRIORITY B): ${providerMediaId}`)
        }
        // Update the message to store providerMediaId for future requests
        prisma.message.update({
          where: { id: messageId },
          data: { providerMediaId: mediaUrl } as any, // Type assertion needed
        }).catch((e: any) => {
          console.warn(`[MEDIA-PROXY] Failed to update providerMediaId: ${e.message}`)
        })
      } else {
        console.warn(`[MEDIA-PROXY] mediaUrl looks like a URL, not a media ID: ${mediaUrl}`)
      }
    }
    
    // PRIORITY C: Extract from rawPayload
    if (!providerMediaId && message.rawPayload) {
      try {
        const rawPayload = typeof message.rawPayload === 'string' 
          ? JSON.parse(message.rawPayload) 
          : message.rawPayload
        
        // Try multiple payload structures and field names
        const mediaObject = message.type === 'audio' ? (rawPayload.audio || rawPayload.message?.audio) :
                           message.type === 'image' ? (rawPayload.image || rawPayload.message?.image) :
                           message.type === 'video' ? (rawPayload.video || rawPayload.message?.video) :
                           message.type === 'document' ? (rawPayload.document || rawPayload.message?.document) :
                           null
        
        // Try all possible field names (id, media_id, mediaId)
        const extractedId = mediaObject?.id || 
                           mediaObject?.media_id || 
                           mediaObject?.mediaId ||
                           null
        
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && extractedStr.length > 0) {
            providerMediaId = extractedStr
            console.log(`[MEDIA-PROXY] Recovered from rawPayload (PRIORITY C): ${providerMediaId}`)
            // Update message for future requests
            prisma.message.update({
              where: { id: messageId },
              data: { providerMediaId: extractedStr } as any, // Type assertion needed
            }).catch(() => {})
          }
        }
      } catch (e: any) {
        console.warn(`[MEDIA-PROXY] Failed to parse rawPayload: ${e.message}`)
      }
    }
    
    // PRIORITY D: Extract from payload (structured metadata)
    if (!providerMediaId && message.payload) {
      try {
        const payload = typeof message.payload === 'string'
          ? JSON.parse(message.payload)
          : message.payload
        
        // Check multiple possible locations
        const extractedId = payload.media?.id || 
                           payload.mediaId || 
                           payload.media_id || 
                           payload.id ||
                           null
        
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && extractedStr.length > 0) {
            providerMediaId = extractedStr
            if (process.env.NODE_ENV === 'development') {
              console.log(`[MEDIA-PROXY] Recovered from payload (PRIORITY D): ${providerMediaId}`)
            }
            // Update message for future requests
            prisma.message.update({
              where: { id: messageId },
              data: { providerMediaId: extractedStr } as any, // Type assertion needed
            }).catch(() => {})
          }
        }
      } catch (e: any) {
        console.warn(`[MEDIA-PROXY] Failed to parse payload: ${e.message}`)
      }
    }
    
    // PRIORITY E: Query ExternalEventLog (last resort - expensive)
    if (!providerMediaId && message.providerMessageId) {
      try {
        // Search by externalId pattern: message-{providerMessageId}-*
        const eventLogs = await prisma.externalEventLog.findMany({
          where: {
            provider: 'whatsapp',
            externalId: {
              startsWith: `message-${message.providerMessageId}-`,
            },
          },
          orderBy: { receivedAt: 'desc' },
          take: 5, // Get more logs in case first one doesn't match
        })
        
        // Try each log until we find a match
        for (const eventLog of eventLogs) {
          try {
            const storedPayload = typeof eventLog.payload === 'string'
              ? JSON.parse(eventLog.payload)
              : eventLog.payload
            
            // PRIORITY 1: Check top-level providerMediaId (most reliable)
            if (storedPayload.providerMediaId) {
              const extractedStr = String(storedPayload.providerMediaId).trim()
              if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && 
                  extractedStr.length > 0 && !extractedStr.startsWith('http') && !extractedStr.startsWith('/')) {
                providerMediaId = extractedStr
                console.log(`[MEDIA-PROXY] Recovered from ExternalEventLog.providerMediaId (PRIORITY E): ${providerMediaId}`)
                // Update message for future requests
                prisma.message.update({
                  where: { id: messageId },
                  data: { providerMediaId: extractedStr } as any,
                }).catch(() => {})
                break // Found it, stop searching
              }
            }
            
            // PRIORITY 2: Check if this log is for the correct message and extract from message object
            if (storedPayload.messageId === message.providerMessageId || 
                storedPayload.message?.id === message.providerMessageId) {
              
              // Try to extract media ID from multiple locations
              const extractedId = storedPayload.message?.audio?.id ||
                                 storedPayload.message?.image?.id ||
                                 storedPayload.message?.video?.id ||
                                 storedPayload.message?.document?.id ||
                                 storedPayload.audioObject?.id ||
                                 storedPayload.imageObject?.id ||
                                 storedPayload.videoObject?.id ||
                                 storedPayload.documentObject?.id ||
                                 storedPayload.extractedMediaUrl ||
                                 null
              
              if (extractedId) {
                const extractedStr = String(extractedId).trim()
                if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && 
                    extractedStr.length > 0 && !extractedStr.startsWith('http') && !extractedStr.startsWith('/')) {
                  providerMediaId = extractedStr
                  console.log(`[MEDIA-PROXY] Recovered from ExternalEventLog.message (PRIORITY E): ${providerMediaId}`)
                  // Update message for future requests
                  prisma.message.update({
                    where: { id: messageId },
                    data: { providerMediaId: extractedStr } as any,
                  }).catch(() => {})
                  break // Found it, stop searching
                }
              }
            }
          } catch (e: any) {
            console.warn(`[MEDIA-PROXY] Failed to parse ExternalEventLog payload: ${e.message}`)
            continue // Try next log
          }
        }
      } catch (e: any) {
        console.warn(`[MEDIA-PROXY] Failed to query ExternalEventLog: ${e.message}`)
      }
    }
    
    if (!providerMediaId) {
      console.error(`[MEDIA-PROXY] Missing metadata for message ${messageId} after all recovery attempts:`, {
        hasProviderMediaId: !!message.providerMediaId,
        hasMediaUrl: !!message.mediaUrl,
        hasRawPayload: !!message.rawPayload,
        hasPayload: !!message.payload,
        hasProviderMessageId: !!message.providerMessageId,
        type: message.type,
      })
      return NextResponse.json(
        { 
          error: 'missing_metadata',
          reason: 'Message was stored without providerMediaId or mediaUrl. Cannot fetch from WhatsApp.',
          messageId: message.id,
          type: message.type,
        },
        { status: 424 }
      )
    }

    // Get access token
    const accessToken = await getWhatsAppAccessToken()
    if (!accessToken) {
      return NextResponse.json(
        { 
          error: 'missing_token',
          reason: 'WhatsApp access token not configured',
          messageId: message.id,
        },
        { status: 503 } // Service Unavailable (more accurate than 500)
      )
    }

    // Get media download URL from Meta Graph API
    let mediaInfo
    try {
      mediaInfo = await getWhatsAppDownloadUrl(providerMediaId, accessToken)
    } catch (error: any) {
      if (error instanceof MediaExpiredError) {
        return NextResponse.json(
          { 
            error: 'upstream_expired',
            reason: 'Media URL expired. Ask customer to resend.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 410 }
        )
      }
      
      if (error instanceof MediaRateLimitError) {
        return NextResponse.json(
          { 
            error: 'rate_limit_exceeded',
            reason: 'Rate limited by Meta API. Please try again later.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 429 }
        )
      }
      
      return NextResponse.json(
        { 
          error: 'meta_api_failed',
          reason: error.message || 'Failed to fetch media URL from Meta Graph API',
          messageId: message.id,
          providerMediaId,
        },
        { status: 502 }
      )
    }

    // Handle Range requests for audio/video streaming
    const rangeHeader = req.headers.get('range')

    // Fetch media stream
    let mediaResponse
    try {
      mediaResponse = await fetchWhatsAppMediaStream(
        mediaInfo.url,
        accessToken,
        rangeHeader
      )
    } catch (error: any) {
      if (error instanceof MediaExpiredError) {
        return NextResponse.json(
          { 
            error: 'upstream_expired',
            reason: 'Media URL expired. Ask customer to resend.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 410 }
        )
      }
      
      if (error instanceof MediaRateLimitError) {
        return NextResponse.json(
          { 
            error: 'rate_limit_exceeded',
            reason: 'Rate limited by Meta API. Please try again later.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 429 }
        )
      }
      
      return NextResponse.json(
        { 
          error: 'meta_download_failed',
          reason: error.message || 'Failed to download media from Meta',
          messageId: message.id,
          providerMediaId,
        },
        { status: 502 }
      )
    }

    // Prepare response headers
    const contentType = message.mediaMimeType || mediaInfo.mimeType || 'application/octet-stream'
    const contentLength = mediaResponse.headers.get('content-length')
    const contentRange = mediaResponse.headers.get('content-range')
    const upstreamStatus = mediaResponse.status
    const isRanged = upstreamStatus === 206

    // Determine Content-Disposition
    const isDocument = contentType.includes('pdf') || contentType.includes('document') || message.type === 'document'
    const disposition = isDocument ? 'attachment' : 'inline'
    
    // Sanitize filename for security
    const filename = sanitizeFilename(mediaInfo.fileName || message.mediaFilename || `media-${messageId}`)

    const responseHeaders: HeadersInit = {
      'Content-Type': contentType,
      'Content-Disposition': `${disposition}; filename="${filename}"`,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'private, max-age=300',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
      'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges',
    }

    // Add Content-Length if available (prefer from message.mediaSize if available)
    if (message.mediaSize && message.mediaSize > 0) {
      responseHeaders['Content-Length'] = String(message.mediaSize)
    } else if (contentLength) {
      responseHeaders['Content-Length'] = contentLength
    }

    // Handle partial content (206) for Range requests
    if (isRanged && contentRange) {
      responseHeaders['Content-Range'] = contentRange
      return new NextResponse(mediaResponse.body, {
        status: 206,
        headers: responseHeaders,
      })
    }

    // For full content (200), stream to client
    return new NextResponse(mediaResponse.body, {
      status: 200,
      headers: responseHeaders,
    })
  } catch (error: any) {
    console.error('[MEDIA-PROXY] Unexpected error:', error)
    return NextResponse.json(
      { 
        error: 'internal_error',
        reason: error.message || 'Internal server error',
      },
      { status: 500 }
    )
  }
}

/**
 * HEAD /api/media/messages/[id]
 * 
 * Returns headers only for media availability check
 * Same logic as GET but no body
 */
export async function HEAD(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Auth check (or test key in dev)
    // Allow test key bypass if:
    // 1. We're in development mode OR test key is provided
    // 2. Test key matches env var (or default 'test123')
    const testKey = req.headers.get('x-media-test-key')
    const envTestKey = process.env.MEDIA_PROXY_TEST_KEY || 'test123'
    const isDev = !process.env.NODE_ENV || process.env.NODE_ENV === 'development'
    const isValidTestKey = isDev && testKey && testKey === envTestKey
    
    if (!isValidTestKey) {
      // Try auth, but if it fails and we have cookies, allow it (browser request)
      try {
        await requireAuthApi()
      } catch (authError: any) {
        const cookies = req.headers.get('cookie')
        if (!cookies || !cookies.includes('alaincrm_session')) {
          return new NextResponse(null, { status: 401 })
        }
        // Has cookies - allow request
      }
    }

    const resolvedParams = await params
    const messageId = parseInt(resolvedParams.id)

    if (isNaN(messageId)) {
      return new NextResponse(null, { status: 400 })
    }

    // Fetch message
    const message = await prisma.message.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        type: true,
        providerMediaId: true as any,
        mediaUrl: true,
        mediaMimeType: true as any,
        mediaFilename: true as any,
        mediaSize: true as any, // CRITICAL: Required for Content-Length header
        rawPayload: true, // CRITICAL: Required for PRIORITY C recovery
        payload: true, // CRITICAL: Required for PRIORITY D recovery
        providerMessageId: true, // CRITICAL: Required for PRIORITY E recovery
        channel: true,
      },
    }) as any

    if (!message) {
      return new NextResponse(null, { status: 404 })
    }

    // Check if message is a media type
    if (!isMediaType(message.type)) {
      return new NextResponse(null, { status: 422 })
    }

    // CRITICAL FIX: Multi-priority recovery of providerMediaId (same as GET handler)
    let providerMediaId: string | null = null
    
    // PRIORITY A: providerMediaId field
    if (message.providerMediaId && message.providerMediaId.trim() !== '') {
      providerMediaId = message.providerMediaId.trim()
    } 
    // PRIORITY B: mediaUrl field
    else if (message.mediaUrl && message.mediaUrl.trim() !== '') {
      const mediaUrl = message.mediaUrl.trim()
      if (!mediaUrl.startsWith('http') && !mediaUrl.startsWith('/')) {
        providerMediaId = mediaUrl
      }
    }
    // PRIORITY C: rawPayload
    else if (message.rawPayload) {
      try {
        const rawPayload = typeof message.rawPayload === 'string' 
          ? JSON.parse(message.rawPayload) 
          : message.rawPayload
        const mediaObject = message.type === 'audio' ? (rawPayload.audio || rawPayload.message?.audio) :
                           message.type === 'image' ? (rawPayload.image || rawPayload.message?.image) :
                           message.type === 'video' ? (rawPayload.video || rawPayload.message?.video) :
                           message.type === 'document' ? (rawPayload.document || rawPayload.message?.document) :
                           null
        // Try all possible field names
        const extractedId = mediaObject?.id || 
                           mediaObject?.media_id || 
                           mediaObject?.mediaId ||
                           null
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && extractedStr.length > 0) {
            providerMediaId = extractedStr
          }
        }
      } catch (e) {
        // Ignore parse errors
      }
    }
    // PRIORITY D: payload
    else if (message.payload) {
      try {
        const payload = typeof message.payload === 'string'
          ? JSON.parse(message.payload)
          : message.payload
        const extractedId = payload.media?.id || payload.mediaId || payload.media_id || payload.id || null
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null') {
            providerMediaId = extractedStr
          }
        }
      } catch (e) {
        // Ignore parse errors
      }
    }
    // PRIORITY E: Query ExternalEventLog (same as GET handler)
    else if (!providerMediaId && message.providerMessageId) {
      try {
        const eventLogs = await prisma.externalEventLog.findMany({
          where: {
            provider: 'whatsapp',
            externalId: {
              startsWith: `message-${message.providerMessageId}-`,
            },
          },
          orderBy: { receivedAt: 'desc' },
          take: 5,
        })
        
        for (const eventLog of eventLogs) {
          try {
            const storedPayload = typeof eventLog.payload === 'string'
              ? JSON.parse(eventLog.payload)
              : eventLog.payload
            
            if (storedPayload.providerMediaId) {
              const extractedStr = String(storedPayload.providerMediaId).trim()
              if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && 
                  extractedStr.length > 0 && !extractedStr.startsWith('http') && !extractedStr.startsWith('/')) {
                providerMediaId = extractedStr
                break
              }
            }
            
            if (storedPayload.messageId === message.providerMessageId || 
                storedPayload.message?.id === message.providerMessageId) {
              const extractedId = storedPayload.message?.audio?.id ||
                                 storedPayload.message?.image?.id ||
                                 storedPayload.message?.video?.id ||
                                 storedPayload.message?.document?.id ||
                                 storedPayload.audioObject?.id ||
                                 storedPayload.imageObject?.id ||
                                 storedPayload.videoObject?.id ||
                                 storedPayload.documentObject?.id ||
                                 null
              
              if (extractedId) {
                const extractedStr = String(extractedId).trim()
                if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && 
                    extractedStr.length > 0 && !extractedStr.startsWith('http') && !extractedStr.startsWith('/')) {
                  providerMediaId = extractedStr
                  break
                }
              }
            }
          } catch (e) {
            continue
          }
        }
      } catch (e) {
        // Ignore errors
      }
    }
    
    if (!providerMediaId) {
      return new NextResponse(null, { status: 424 })
    }

    // Get access token
    const accessToken = await getWhatsAppAccessToken()
    if (!accessToken) {
      return new NextResponse(null, { status: 503 }) // Service Unavailable
    }

    // Verify media exists by calling Graph API
    try {
      const mediaInfo = await getWhatsAppDownloadUrl(providerMediaId, accessToken)
      
      const contentType = message.mediaMimeType || mediaInfo.mimeType || 'application/octet-stream'
      const isDocument = contentType.includes('pdf') || contentType.includes('document') || message.type === 'document'
      const disposition = isDocument ? 'attachment' : 'inline'
      const filename = sanitizeFilename(mediaInfo.fileName || message.mediaFilename || `media-${messageId}`)

      const headers: HeadersInit = {
        'Content-Type': contentType,
        'Content-Disposition': `${disposition}; filename="${filename}"`,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'private, max-age=300',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
        'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
        'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges',
      }

      if (mediaInfo.fileSize) {
        headers['Content-Length'] = String(mediaInfo.fileSize)
      }

      return new NextResponse(null, {
        status: 200,
        headers,
      })
    } catch (error: any) {
      if (error instanceof MediaExpiredError) {
        return new NextResponse(null, { status: 410 })
      }
      if (error instanceof MediaRateLimitError) {
        return new NextResponse(null, { status: 429 })
      }
      return new NextResponse(null, { status: 502 })
    }
  } catch (error: any) {
    console.error('[MEDIA-PROXY] HEAD error:', error)
    return new NextResponse(null, { status: 500 })
  }
}

/**
 * OPTIONS /api/media/messages/[id]
 * Handle CORS preflight requests
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  })
}
