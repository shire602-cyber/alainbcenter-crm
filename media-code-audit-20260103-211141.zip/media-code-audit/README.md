# Media Code Audit - Complete Codebase

This archive contains ALL code related to:
- Media handling (images, PDFs, audio, video)
- WhatsApp media integration
- Media proxy and storage
- Media recovery mechanisms
- Frontend media components

## Current Issue Status

**CONFIRMED NOT WORKING:**
- Recent media messages (ID 2381+) have:
  - providerMediaId: NULL
  - mediaUrl: NULL
  - rawPayload: NULL
  - payload: NULL
- All recovery mechanisms fail because no data is stored
- Frontend shows "[Media message]" placeholders

## File Structure

See individual files for complete code.

## Key Files

1. **Webhook**: `src/app/api/webhooks/whatsapp/route.ts` - Extracts media from webhook
2. **Pipeline**: `src/lib/inbound/autoMatchPipeline.ts` - Stores media in DB
3. **Proxy**: `src/app/api/media/messages/[id]/route.ts` - Fetches media from WhatsApp
4. **Frontend**: `src/app/inbox/page.tsx` - Renders media messages
