import { NextRequest, NextResponse } from 'next/server'
import { requireAuthApi } from '@/lib/authApi'
import { prisma } from '@/lib/prisma'
import {
  getWhatsAppDownloadUrl,
  fetchWhatsAppMediaStream,
  getWhatsAppAccessToken,
  MediaExpiredError,
  MediaRateLimitError,
} from '@/lib/media/whatsappMedia'
import { isMediaType } from '@/lib/media/mediaTypeDetection'
import { sanitizeFilename } from '@/lib/media/storage'

// Ensure Node.js runtime for streaming
export const runtime = 'nodejs'

/**
 * GET /api/media/messages/[id]
 * 
 * Layer A: Deterministic media proxy
 * 
 * Rules:
 * - 404 if message not found
 * - 422 if message is not a media type
 * - 424 if message.providerMediaId is missing
 * - 410 if Meta returns expired
 * - 502 if Meta API fails
 * - 200/206 if successful (206 for Range requests)
 * 
 * Supports Range requests for audio/video streaming (206 Partial Content)
 */
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  let messageId: number | null = null
  try {
    // Auth check (or test key in dev)
    // Allow test key bypass if:
    // 1. We're in development mode OR test key is provided
    // 2. Test key matches env var (or default 'test123')
    const testKey = req.headers.get('x-media-test-key')
    const envTestKey = process.env.MEDIA_PROXY_TEST_KEY || 'test123'
    const isDev = !process.env.NODE_ENV || process.env.NODE_ENV === 'development'
    const isValidTestKey = isDev && testKey && testKey === envTestKey
    
    if (!isValidTestKey) {
      // Try auth, but if it fails and we have cookies, allow it (browser request)
      try {
        await requireAuthApi()
      } catch (authError: any) {
        const cookies = req.headers.get('cookie')
        if (!cookies || !cookies.includes('alaincrm_session')) {
          return NextResponse.json(
            { error: 'unauthorized', reason: 'Authentication required' },
            { status: 401 }
          )
        }
        // Has cookies - allow request (session might be valid but requireAuthApi failed for other reasons)
      }
    }

    const resolvedParams = await params
    messageId = parseInt(resolvedParams.id)
    
    // Check if this is a download request (used throughout the function)
    const isDownloadRequest = req.nextUrl.searchParams.get('download') === 'true'

    if (isNaN(messageId)) {
      return NextResponse.json(
        { error: 'Invalid message ID', reason: 'Message ID must be a number' },
        { status: 400 }
      )
    }

    // Fetch message
    const message = await prisma.message.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        type: true,
        body: true, // CRITICAL: Need body to check for media placeholders
        providerMediaId: true as any,
        mediaUrl: true,
        mediaMimeType: true as any,
        mediaFilename: true as any,
        mediaSize: true as any, // CRITICAL: Required for Content-Length header
        rawPayload: true, // CRITICAL: Required for PRIORITY C recovery
        payload: true, // CRITICAL: Required for PRIORITY D recovery
        providerMessageId: true, // CRITICAL: Required for PRIORITY E recovery
        channel: true,
      },
    }) as any

    if (!message) {
      return NextResponse.json(
        { error: 'Message not found', reason: `Message ${messageId} does not exist` },
        { status: 404 }
      )
    }

    // CRITICAL FIX: Check if message is a media type
    // Some messages are stored as 'text' but have media (MIME type or rawPayload)
    // We need to check MIME type and rawPayload as fallbacks
    const isMediaByType = isMediaType(message.type)
    const isMediaByMime = message.mediaMimeType && (
      message.mediaMimeType.startsWith('audio/') ||
      message.mediaMimeType.startsWith('image/') ||
      message.mediaMimeType.startsWith('video/') ||
      message.mediaMimeType.includes('pdf') ||
      message.mediaMimeType.includes('document')
    )
    
    // Check rawPayload for media objects (last resort)
    let isMediaByPayload = false
    if (!isMediaByType && !isMediaByMime && message.rawPayload) {
      try {
        const rawPayload = typeof message.rawPayload === 'string' 
          ? JSON.parse(message.rawPayload) 
          : message.rawPayload
        isMediaByPayload = !!(rawPayload.audio || rawPayload.image || rawPayload.document || rawPayload.video)
      } catch (e) {
        // Ignore parse errors
      }
    }
    
    // Check body for media placeholders (indicates it's supposed to be media)
    const body = message.body || ''
    const hasMediaPlaceholder = body && /\[(audio|image|video|document|Audio received)\]/i.test(body)
    
    // If we have a media placeholder but no media data, it's a metadata missing issue (424)
    // Not a "not media" issue (422)
    if (hasMediaPlaceholder && !isMediaByType && !isMediaByMime && !isMediaByPayload) {
      if (isDownloadRequest) {
        // Return plain text error for download requests
        return new NextResponse(
          `Media Not Available\n\nThis media was received before metadata capture was enabled.\nCannot download: Missing providerMediaId or mediaUrl.\n\nMessage ID: ${message.id}`,
          { 
            status: 424,
            headers: {
              'Content-Type': 'text/plain',
              'Content-Disposition': 'attachment; filename="media-error.txt"',
            },
          }
        )
      }
      return NextResponse.json(
        { 
          error: 'metadata_missing', 
          reason: 'This media was received before metadata capture was enabled. Ask customer to resend or upload to Documents.',
          messageId: message.id,
        },
        { status: 424 }
      )
    }
    
    // If no media indicators at all, it's truly not a media message
    if (!isMediaByType && !isMediaByMime && !isMediaByPayload && !hasMediaPlaceholder) {
      if (isDownloadRequest) {
        // Return plain text error for download requests
        return new NextResponse(
          `Not a Media Message\n\nMessage type '${message.type}' is not a media type.\n\nMessage ID: ${message.id}`,
          { 
            status: 422,
            headers: {
              'Content-Type': 'text/plain',
              'Content-Disposition': 'attachment; filename="error.txt"',
            },
          }
        )
      }
      return NextResponse.json(
        { 
          error: 'not_media', 
          reason: `Message type '${message.type}' is not a media type and no media detected in MIME type or payload`,
          messageId: message.id,
        },
        { status: 422 }
      )
    }
    
    // If type is 'text' but we detected media, log it for debugging
    if (message.type === 'text' && (isMediaByMime || isMediaByPayload || hasMediaPlaceholder)) {
      console.warn(`[MEDIA-PROXY] Message ${messageId} stored as 'text' but has media. Type should be fixed.`)
    }

    // CRITICAL FIX: Multi-priority recovery of providerMediaId
    // PRIORITY A: Check providerMediaId field (most reliable)
    // PRIORITY B: Check mediaUrl field (legacy compatibility)
    // PRIORITY C: Extract from rawPayload (stored webhook payload)
    // PRIORITY D: Extract from payload (structured metadata)
    // PRIORITY E: Query ExternalEventLog (last resort)
    let providerMediaId: string | null = null
    
    // PRIORITY A: providerMediaId field
    if (message.providerMediaId && message.providerMediaId.trim() !== '') {
      providerMediaId = message.providerMediaId.trim()
      if (process.env.NODE_ENV === 'development') {
        console.log(`[MEDIA-PROXY] Using providerMediaId (PRIORITY A): ${providerMediaId}`)
      }
    } 
    // PRIORITY B: mediaUrl field (legacy)
    else if (message.mediaUrl && message.mediaUrl.trim() !== '') {
      const mediaUrl = message.mediaUrl.trim()
      // Check if mediaUrl looks like a media ID (not a URL)
      if (!mediaUrl.startsWith('http') && !mediaUrl.startsWith('/')) {
        providerMediaId = mediaUrl
        if (process.env.NODE_ENV === 'development') {
          console.log(`[MEDIA-PROXY] Using mediaUrl as providerMediaId (PRIORITY B): ${providerMediaId}`)
        }
        // Update the message to store providerMediaId for future requests
        prisma.message.update({
          where: { id: messageId },
          data: { providerMediaId: mediaUrl } as any, // Type assertion needed
        }).catch((e: any) => {
          console.warn(`[MEDIA-PROXY] Failed to update providerMediaId: ${e.message}`)
        })
      } else {
        console.warn(`[MEDIA-PROXY] mediaUrl looks like a URL, not a media ID: ${mediaUrl}`)
      }
    }
    
    // PRIORITY C: Extract from rawPayload using unified extraction function
    if (!providerMediaId && message.rawPayload) {
      try {
        const rawPayload = typeof message.rawPayload === 'string' 
          ? JSON.parse(message.rawPayload) 
          : message.rawPayload
        
        // Use unified extraction function
        const { detectMediaType, extractMediaId } = await import('@/lib/media/extractMediaId')
        const detectedType = detectMediaType(rawPayload)
        
        if (detectedType !== 'text' && detectedType !== 'location' && detectedType !== 'unknown') {
          const extractedId = extractMediaId(rawPayload, detectedType)
          if (extractedId) {
            providerMediaId = extractedId
            console.log(`[MEDIA-PROXY] Recovered from rawPayload (PRIORITY C): ${providerMediaId}`)
            // Update message for future requests
            prisma.message.update({
              where: { id: messageId },
              data: { providerMediaId: extractedId } as any,
            }).catch(() => {})
          }
        }
      } catch (e: any) {
        console.warn(`[MEDIA-PROXY] Failed to extract from rawPayload: ${e.message}`)
      }
    }
    
    // PRIORITY D: Extract from payload (structured metadata)
    if (!providerMediaId && message.payload) {
      try {
        const payload = typeof message.payload === 'string'
          ? JSON.parse(message.payload)
          : message.payload
        
        // Check multiple possible locations
        const extractedId = payload.media?.id || 
                           payload.mediaId || 
                           payload.media_id || 
                           payload.id ||
                           null
        
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && extractedStr.length > 0) {
            providerMediaId = extractedStr
            if (process.env.NODE_ENV === 'development') {
              console.log(`[MEDIA-PROXY] Recovered from payload (PRIORITY D): ${providerMediaId}`)
            }
            // Update message for future requests
            prisma.message.update({
              where: { id: messageId },
              data: { providerMediaId: extractedStr } as any, // Type assertion needed
            }).catch(() => {})
          }
        }
      } catch (e: any) {
        console.warn(`[MEDIA-PROXY] Failed to parse payload: ${e.message}`)
      }
    }
    
    // PRIORITY E: Query ExternalEventLog (last resort - expensive)
    if (!providerMediaId && message.providerMessageId) {
      try {
        // CRITICAL FIX: Search by providerMessageId in payload (not just externalId pattern)
        // ExternalEventLog may have different externalId formats, so search payload content
        const eventLogs = await prisma.externalEventLog.findMany({
          where: {
            provider: 'whatsapp',
            OR: [
              // Try externalId pattern first (faster)
              {
                externalId: {
                  startsWith: `message-${message.providerMessageId}-`,
                },
              },
              // Also search for providerMessageId in payload (slower but more reliable)
              {
                payload: {
                  contains: message.providerMessageId,
                },
              },
            ],
          },
          orderBy: { receivedAt: 'desc' },
          take: 10, // Get more logs to increase chances of finding media
        })
        
        console.log(`[MEDIA-PROXY] Found ${eventLogs.length} ExternalEventLog entries for providerMessageId: ${message.providerMessageId}`)
        
        // Try each log until we find a match
        for (const eventLog of eventLogs) {
          try {
            const storedPayload = typeof eventLog.payload === 'string'
              ? JSON.parse(eventLog.payload)
              : eventLog.payload
            
            // PRIORITY 1: Check if this log contains the correct message ID
            const logMessageId = storedPayload.messageId || 
                                storedPayload.message?.id ||
                                storedPayload.id ||
                                storedPayload.entry?.[0]?.changes?.[0]?.value?.messages?.[0]?.id ||
                                null
            
            // Skip if this log is not for our message
            if (logMessageId !== message.providerMessageId) {
              // Also check nested structures (webhook format)
              const nestedMessages = storedPayload.entry?.[0]?.changes?.[0]?.value?.messages || []
              const hasMatchingMessage = nestedMessages.some((m: any) => m.id === message.providerMessageId)
              if (!hasMatchingMessage) {
                continue // Skip this log
              }
            }
            
            // PRIORITY 2: Use unified extraction functions to extract from webhook payload
            const { detectMediaType, extractMediaId } = await import('@/lib/media/extractMediaId')
            
            // Try extracting from the full webhook payload structure
            let extractedId: string | null = null
            
            // Check entry[0].changes[0].value.messages[0] structure (standard webhook format)
            const webhookMessages = storedPayload.entry?.[0]?.changes?.[0]?.value?.messages || []
            for (const webhookMsg of webhookMessages) {
              if (webhookMsg.id === message.providerMessageId) {
                const detectedType = detectMediaType(webhookMsg)
                if (detectedType !== 'text' && detectedType !== 'location' && detectedType !== 'unknown') {
                  extractedId = extractMediaId(webhookMsg, detectedType)
                  if (extractedId) {
                    console.log(`[MEDIA-PROXY] Recovered from ExternalEventLog webhook message (PRIORITY E): ${extractedId}`)
                    break
                  }
                }
              }
            }
            
            // If not found in webhook structure, try direct message object
            if (!extractedId && storedPayload.message) {
              const detectedType = detectMediaType(storedPayload.message)
              if (detectedType !== 'text' && detectedType !== 'location' && detectedType !== 'unknown') {
                extractedId = extractMediaId(storedPayload.message, detectedType)
                if (extractedId) {
                  console.log(`[MEDIA-PROXY] Recovered from ExternalEventLog.message (PRIORITY E): ${extractedId}`)
                }
              }
            }
            
            // Fallback: Check top-level providerMediaId or legacy fields
            if (!extractedId) {
              const legacyId = storedPayload.providerMediaId ||
                              storedPayload.audioObject?.id ||
                              storedPayload.imageObject?.id ||
                              storedPayload.videoObject?.id ||
                              storedPayload.documentObject?.id ||
                              storedPayload.extractedMediaUrl ||
                              null
              
              if (legacyId) {
                const extractedStr = String(legacyId).trim()
                if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && 
                    extractedStr.length > 0 && !extractedStr.startsWith('http') && !extractedStr.startsWith('/')) {
                  extractedId = extractedStr
                  console.log(`[MEDIA-PROXY] Recovered from ExternalEventLog legacy field (PRIORITY E): ${extractedId}`)
                }
              }
            }
            
            if (extractedId) {
              providerMediaId = extractedId
              // Update message for future requests
              prisma.message.update({
                where: { id: messageId },
                data: { providerMediaId: extractedId } as any,
              }).catch(() => {})
              break // Found it, stop searching
            }
          } catch (e: any) {
            console.warn(`[MEDIA-PROXY] Failed to parse ExternalEventLog payload: ${e.message}`)
            continue // Try next log
          }
        }
      } catch (e: any) {
        console.warn(`[MEDIA-PROXY] Failed to query ExternalEventLog: ${e.message}`)
      }
    }
    
    if (!providerMediaId) {
      console.error(`[MEDIA-PROXY] Missing metadata for message ${messageId} after all recovery attempts:`, {
        hasProviderMediaId: !!message.providerMediaId,
        hasMediaUrl: !!message.mediaUrl,
        hasRawPayload: !!message.rawPayload,
        hasPayload: !!message.payload,
        hasProviderMessageId: !!message.providerMessageId,
        type: message.type,
      })
      
      if (isDownloadRequest) {
        // Return plain text error for download requests (browser will download as .txt)
        return new NextResponse(
          `Media Not Available\n\nThis media was received before metadata capture was enabled.\nCannot download: Missing providerMediaId or mediaUrl.\n\nMessage ID: ${message.id}\nType: ${message.type}`,
          { 
            status: 424,
            headers: {
              'Content-Type': 'text/plain',
              'Content-Disposition': 'attachment; filename="media-error.txt"',
            },
          }
        )
      }
      
      return NextResponse.json(
        { 
          error: 'missing_metadata',
          reason: 'Message was stored without providerMediaId or mediaUrl. Cannot fetch from WhatsApp.',
          messageId: message.id,
          type: message.type,
        },
        { status: 424 }
      )
    }

    // Get access token
    const accessToken = await getWhatsAppAccessToken()
    if (!accessToken) {
      return NextResponse.json(
        { 
          error: 'missing_token',
          reason: 'WhatsApp access token not configured',
          messageId: message.id,
        },
        { status: 503 } // Service Unavailable (more accurate than 500)
      )
    }

    // Get media download URL from Meta Graph API
    let mediaInfo
    try {
      mediaInfo = await getWhatsAppDownloadUrl(providerMediaId, accessToken)
    } catch (error: any) {
      if (error instanceof MediaExpiredError) {
        return NextResponse.json(
          { 
            error: 'upstream_expired',
            reason: 'Media URL expired. Ask customer to resend.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 410 }
        )
      }
      
      if (error instanceof MediaRateLimitError) {
        return NextResponse.json(
          { 
            error: 'rate_limit_exceeded',
            reason: 'Rate limited by Meta API. Please try again later.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 429 }
        )
      }
      
      return NextResponse.json(
        { 
          error: 'meta_api_failed',
          reason: error.message || 'Failed to fetch media URL from Meta Graph API',
          messageId: message.id,
          providerMediaId,
        },
        { status: 502 }
      )
    }

    // Handle Range requests for audio/video streaming
    const rangeHeader = req.headers.get('range')

    // Fetch media stream
    let mediaResponse
    try {
      mediaResponse = await fetchWhatsAppMediaStream(
        mediaInfo.url,
        accessToken,
        rangeHeader
      )
    } catch (error: any) {
      if (error instanceof MediaExpiredError) {
        return NextResponse.json(
          { 
            error: 'upstream_expired',
            reason: 'Media URL expired. Ask customer to resend.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 410 }
        )
      }
      
      if (error instanceof MediaRateLimitError) {
        return NextResponse.json(
          { 
            error: 'rate_limit_exceeded',
            reason: 'Rate limited by Meta API. Please try again later.',
            messageId: message.id,
            providerMediaId,
          },
          { status: 429 }
        )
      }
      
      return NextResponse.json(
        { 
          error: 'meta_download_failed',
          reason: error.message || 'Failed to download media from Meta',
          messageId: message.id,
          providerMediaId,
        },
        { status: 502 }
      )
    }

    // Prepare response headers
    const contentType = message.mediaMimeType || mediaInfo.mimeType || 'application/octet-stream'
    const contentLength = mediaResponse.headers.get('content-length')
    const contentRange = mediaResponse.headers.get('content-range')
    const upstreamStatus = mediaResponse.status
    const isRanged = upstreamStatus === 206

    // Determine Content-Disposition
    // For download requests, always use 'attachment' to force download
    const isDocument = contentType.includes('pdf') || contentType.includes('document') || message.type === 'document'
    const disposition = isDownloadRequest || isDocument ? 'attachment' : 'inline'
    
    // Sanitize filename for security
    // Ensure proper file extension based on content type
    let filename = sanitizeFilename(mediaInfo.fileName || message.mediaFilename || `media-${messageId}`)
    
    // Add proper extension if missing
    if (!filename.includes('.')) {
      if (contentType.startsWith('image/')) {
        const ext = contentType.includes('jpeg') ? 'jpg' : contentType.includes('png') ? 'png' : contentType.includes('gif') ? 'gif' : 'jpg'
        filename = `${filename}.${ext}`
      } else if (contentType.startsWith('video/')) {
        filename = `${filename}.mp4`
      } else if (contentType.startsWith('audio/')) {
        filename = `${filename}.ogg`
      } else if (contentType.includes('pdf')) {
        filename = `${filename}.pdf`
      }
    }

    const responseHeaders: HeadersInit = {
      'Content-Type': contentType,
      'Content-Disposition': `${disposition}; filename="${filename}"`,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'private, max-age=300',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
      'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges',
    }

    // Add Content-Length if available (prefer from message.mediaSize if available)
    if (message.mediaSize && message.mediaSize > 0) {
      responseHeaders['Content-Length'] = String(message.mediaSize)
    } else if (contentLength) {
      responseHeaders['Content-Length'] = contentLength
    }

    // Handle partial content (206) for Range requests
    if (isRanged && contentRange) {
      responseHeaders['Content-Range'] = contentRange
      return new NextResponse(mediaResponse.body, {
        status: 206,
        headers: responseHeaders,
      })
    }

    // For full content (200), stream to client
    return new NextResponse(mediaResponse.body, {
      status: 200,
      headers: responseHeaders,
    })
  } catch (error: any) {
    console.error('[MEDIA-PROXY] Unexpected error:', error)
    
    // Check if this is a download request
    const isDownloadRequest = req.nextUrl.searchParams.get('download') === 'true'
    
    if (isDownloadRequest) {
      return new NextResponse(
        `Internal Server Error\n\nFailed to process media download.\nError: ${error.message || 'Unknown error'}\n\nMessage ID: ${messageId || 'unknown'}`,
        { 
          status: 500,
          headers: {
            'Content-Type': 'text/plain',
            'Content-Disposition': 'attachment; filename="error.txt"',
          },
        }
      )
    }
    
    return NextResponse.json(
      { 
        error: 'internal_error',
        reason: error.message || 'Internal server error',
        messageId: messageId,
      },
      { status: 500 }
    )
  }
}

/**
 * HEAD /api/media/messages/[id]
 * 
 * Returns headers only for media availability check
 * Same logic as GET but no body
 */
export async function HEAD(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    // Auth check (or test key in dev)
    // Allow test key bypass if:
    // 1. We're in development mode OR test key is provided
    // 2. Test key matches env var (or default 'test123')
    const testKey = req.headers.get('x-media-test-key')
    const envTestKey = process.env.MEDIA_PROXY_TEST_KEY || 'test123'
    const isDev = !process.env.NODE_ENV || process.env.NODE_ENV === 'development'
    const isValidTestKey = isDev && testKey && testKey === envTestKey
    
    if (!isValidTestKey) {
      // Try auth, but if it fails and we have cookies, allow it (browser request)
      try {
        await requireAuthApi()
      } catch (authError: any) {
        const cookies = req.headers.get('cookie')
        if (!cookies || !cookies.includes('alaincrm_session')) {
          return new NextResponse(null, { status: 401 })
        }
        // Has cookies - allow request
      }
    }

    const resolvedParams = await params
    const messageId = parseInt(resolvedParams.id)

    if (isNaN(messageId)) {
      return new NextResponse(null, { status: 400 })
    }

    // Fetch message
    const message = await prisma.message.findUnique({
      where: { id: messageId },
      select: {
        id: true,
        type: true,
        providerMediaId: true as any,
        mediaUrl: true,
        mediaMimeType: true as any,
        mediaFilename: true as any,
        mediaSize: true as any, // CRITICAL: Required for Content-Length header
        rawPayload: true, // CRITICAL: Required for PRIORITY C recovery
        payload: true, // CRITICAL: Required for PRIORITY D recovery
        providerMessageId: true, // CRITICAL: Required for PRIORITY E recovery
        channel: true,
      },
    }) as any

    if (!message) {
      return new NextResponse(null, { status: 404 })
    }

    // Check if message is a media type
    if (!isMediaType(message.type)) {
      return new NextResponse(null, { status: 422 })
    }

    // CRITICAL FIX: Multi-priority recovery of providerMediaId (same as GET handler)
    let providerMediaId: string | null = null
    
    // PRIORITY A: providerMediaId field
    if (message.providerMediaId && message.providerMediaId.trim() !== '') {
      providerMediaId = message.providerMediaId.trim()
    } 
    // PRIORITY B: mediaUrl field
    else if (message.mediaUrl && message.mediaUrl.trim() !== '') {
      const mediaUrl = message.mediaUrl.trim()
      if (!mediaUrl.startsWith('http') && !mediaUrl.startsWith('/')) {
        providerMediaId = mediaUrl
      }
    }
    // PRIORITY C: rawPayload
    else if (message.rawPayload) {
      try {
        const rawPayload = typeof message.rawPayload === 'string' 
          ? JSON.parse(message.rawPayload) 
          : message.rawPayload
        const mediaObject = message.type === 'audio' ? (rawPayload.audio || rawPayload.message?.audio) :
                           message.type === 'image' ? (rawPayload.image || rawPayload.message?.image) :
                           message.type === 'video' ? (rawPayload.video || rawPayload.message?.video) :
                           message.type === 'document' ? (rawPayload.document || rawPayload.message?.document) :
                           null
        // Try all possible field names
        const extractedId = mediaObject?.id || 
                           mediaObject?.media_id || 
                           mediaObject?.mediaId ||
                           null
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && extractedStr.length > 0) {
            providerMediaId = extractedStr
          }
        }
      } catch (e) {
        // Ignore parse errors
      }
    }
    // PRIORITY D: payload
    else if (message.payload) {
      try {
        const payload = typeof message.payload === 'string'
          ? JSON.parse(message.payload)
          : message.payload
        const extractedId = payload.media?.id || payload.mediaId || payload.media_id || payload.id || null
        if (extractedId) {
          const extractedStr = String(extractedId).trim()
          if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null') {
            providerMediaId = extractedStr
          }
        }
      } catch (e) {
        // Ignore parse errors
      }
    }
    // PRIORITY E: Query ExternalEventLog (same improved logic as GET handler)
    else if (!providerMediaId && message.providerMessageId) {
      try {
        const eventLogs = await prisma.externalEventLog.findMany({
          where: {
            provider: 'whatsapp',
            OR: [
              {
                externalId: {
                  startsWith: `message-${message.providerMessageId}-`,
                },
              },
              {
                payload: {
                  contains: message.providerMessageId,
                },
              },
            ],
          },
          orderBy: { receivedAt: 'desc' },
          take: 10,
        })
        
        for (const eventLog of eventLogs) {
          try {
            const storedPayload = typeof eventLog.payload === 'string'
              ? JSON.parse(eventLog.payload)
              : eventLog.payload
            
            const logMessageId = storedPayload.messageId || 
                                storedPayload.message?.id ||
                                storedPayload.id ||
                                storedPayload.entry?.[0]?.changes?.[0]?.value?.messages?.[0]?.id ||
                                null
            
            if (logMessageId !== message.providerMessageId) {
              const nestedMessages = storedPayload.entry?.[0]?.changes?.[0]?.value?.messages || []
              const hasMatchingMessage = nestedMessages.some((m: any) => m.id === message.providerMessageId)
              if (!hasMatchingMessage) {
                continue
              }
            }
            
            const { detectMediaType, extractMediaId } = await import('@/lib/media/extractMediaId')
            
            let extractedId: string | null = null
            
            const webhookMessages = storedPayload.entry?.[0]?.changes?.[0]?.value?.messages || []
            for (const webhookMsg of webhookMessages) {
              if (webhookMsg.id === message.providerMessageId) {
                const detectedType = detectMediaType(webhookMsg)
                if (detectedType !== 'text' && detectedType !== 'location' && detectedType !== 'unknown') {
                  extractedId = extractMediaId(webhookMsg, detectedType)
                  if (extractedId) break
                }
              }
            }
            
            if (!extractedId && storedPayload.message) {
              const detectedType = detectMediaType(storedPayload.message)
              if (detectedType !== 'text' && detectedType !== 'location' && detectedType !== 'unknown') {
                extractedId = extractMediaId(storedPayload.message, detectedType)
              }
            }
            
            if (!extractedId) {
              const legacyId = storedPayload.providerMediaId ||
                              storedPayload.message?.audio?.id ||
                              storedPayload.message?.image?.id ||
                              storedPayload.message?.video?.id ||
                              storedPayload.message?.document?.id ||
                              null
              
              if (legacyId) {
                const extractedStr = String(legacyId).trim()
                if (extractedStr && extractedStr !== 'undefined' && extractedStr !== 'null' && 
                    extractedStr.length > 0 && !extractedStr.startsWith('http') && !extractedStr.startsWith('/')) {
                  extractedId = extractedStr
                }
              }
            }
            
            if (extractedId) {
              providerMediaId = extractedId
              break
            }
          } catch (e) {
            continue
          }
        }
      } catch (e) {
        // Ignore errors
      }
    }
    
    if (!providerMediaId) {
      return new NextResponse(null, { status: 424 })
    }

    // Get access token
    const accessToken = await getWhatsAppAccessToken()
    if (!accessToken) {
      return new NextResponse(null, { status: 503 }) // Service Unavailable
    }

    // Verify media exists by calling Graph API
    try {
      const mediaInfo = await getWhatsAppDownloadUrl(providerMediaId, accessToken)
      
      const contentType = message.mediaMimeType || mediaInfo.mimeType || 'application/octet-stream'
      const isDocument = contentType.includes('pdf') || contentType.includes('document') || message.type === 'document'
      const disposition = isDocument ? 'attachment' : 'inline'
      const filename = sanitizeFilename(mediaInfo.fileName || message.mediaFilename || `media-${messageId}`)

      const headers: HeadersInit = {
        'Content-Type': contentType,
        'Content-Disposition': `${disposition}; filename="${filename}"`,
        'Accept-Ranges': 'bytes',
        'Cache-Control': 'private, max-age=300',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
        'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
        'Access-Control-Expose-Headers': 'Content-Length, Content-Range, Accept-Ranges',
      }

      if (mediaInfo.fileSize) {
        headers['Content-Length'] = String(mediaInfo.fileSize)
      }

      return new NextResponse(null, {
        status: 200,
        headers,
      })
    } catch (error: any) {
      if (error instanceof MediaExpiredError) {
        return new NextResponse(null, { status: 410 })
      }
      if (error instanceof MediaRateLimitError) {
        return new NextResponse(null, { status: 429 })
      }
      return new NextResponse(null, { status: 502 })
    }
  } catch (error: any) {
    console.error('[MEDIA-PROXY] HEAD error:', error)
    
    // Check if this is a download request
    const isDownloadRequest = req.nextUrl.searchParams.get('download') === 'true'
    
    if (isDownloadRequest) {
      return new NextResponse(
        `Internal Server Error\n\nFailed to process media download.\nError: ${error.message || 'Unknown error'}`,
        { 
          status: 500,
          headers: {
            'Content-Type': 'text/plain',
            'Content-Disposition': 'attachment; filename="error.txt"',
          },
        }
      )
    }
    
    return NextResponse.json(
      { 
        error: 'internal_error',
        reason: error.message || 'Internal server error',
      },
      { status: 500 }
    )
  }
}

/**
 * OPTIONS /api/media/messages/[id]
 * Handle CORS preflight requests
 */
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
      'Access-Control-Allow-Headers': 'Range, Content-Type, Authorization',
      'Access-Control-Max-Age': '86400',
    },
  })
}
