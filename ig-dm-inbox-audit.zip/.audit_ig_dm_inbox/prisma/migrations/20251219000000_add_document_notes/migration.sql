-- AlterTable
ALTER TABLE "Document" ADD COLUMN "notes" TEXT;

















