-- Add dueDate and notes fields to ChecklistItem
ALTER TABLE "ChecklistItem" ADD COLUMN "dueDate" TIMESTAMP(3);
ALTER TABLE "ChecklistItem" ADD COLUMN "notes" TEXT;























